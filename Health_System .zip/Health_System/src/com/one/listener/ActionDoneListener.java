package com.one.listener;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Interface
 * Date             : 01/04/2024
 */

public interface ActionDoneListener {
    void done(Object result);
}
