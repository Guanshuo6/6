package com.one.ui;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Manager interface
 * Date             : 29/03/2024
 */

import com.one.component.*;
import com.one.util.ScreenUtils;
import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class ManagerInterface {

    JFrame jf = new JFrame("Health Manager");

    final int WIDTH = 1360;
    final int HEIGHT = 750;

    // Assembling frames
    public void init() {

        // Set Attributes of frame
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);
        jf.setResizable(false);
        jf.setIconImage(new ImageIcon("images/logo.png").getImage());
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Navi-bar
        JMenuBar jmb = new JMenuBar();
        JMenu jMenu = new JMenu("Settings");
        JMenuItem m1 = new JMenuItem("Change Account");
        JMenuItem m2 = new JMenuItem("Exit system");
        m1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new MainInterface().init();
                    jf.dispose();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        m2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Exit
                System.exit(0);
            }
        });
        jMenu.add(m1);
        jMenu.add(m2);
        jmb.add(jMenu);
        jf.setJMenuBar(jmb);

        // Split panels
        JSplitPane sp = new JSplitPane();

        // Support continuously layout
        sp.setContinuousLayout(true);
        sp.setDividerLocation(200);
        sp.setDividerSize(7);

        // Set left contents
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("  System Manager");
        DefaultMutableTreeNode userManage = new DefaultMutableTreeNode("  Client Manager");
        DefaultMutableTreeNode intake = new DefaultMutableTreeNode("  Calories intake");
        DefaultMutableTreeNode burned = new DefaultMutableTreeNode("  Calories Burned");
        DefaultMutableTreeNode conditions = new DefaultMutableTreeNode("  Physical Conditions");
        DefaultMutableTreeNode summarize = new DefaultMutableTreeNode("  Summarize");

        root.add(userManage);
        root.add(intake);
        root.add(burned);
        root.add(conditions);
        root.add(summarize);

        JTree tree = new JTree(root);
        // Add Spaces for tree
        tree.setRowHeight(40);
        Color color = new Color(0, 11, 28);
        MyRederer myRederer = new MyRederer();
        myRederer.setBackgroundNonSelectionColor(color);
        myRederer.setBackgroundSelectionColor(new Color(12, 34, 56));

        tree.setCellRenderer(myRederer);
        tree.setBackground(color);
        // Set current default select User Manager
        // tree.setSelectionRow(1);
        tree.addTreeSelectionListener(new TreeSelectionListener() {
            // When select different will run here
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                // Get current node object
                Object lastPathComponent = e.getNewLeadSelectionPath().getLastPathComponent();

                if (userManage.equals(lastPathComponent)) {
                    sp.setRightComponent(new ClientManagerComponent(jf));
                    sp.setDividerLocation(200);
                } else if (intake.equals(lastPathComponent)) {
                    sp.setRightComponent(new ClientIntakeComponent(jf));
                    sp.setDividerLocation(200);
                } else if (burned.equals(lastPathComponent)) {
                    sp.setRightComponent(new ClientCaloriesComponent(jf));
                    sp.setDividerLocation(200);
                } else if (conditions.equals(lastPathComponent)) {
                    sp.setRightComponent(new ClientDiseaseComponent(jf));
                    sp.setDividerLocation(200);
                } else if (summarize.equals(lastPathComponent)) {
                    sp.setRightComponent(new ClientSummarizeComponent(jf));
                    sp.setDividerLocation(200);
                }
            }
        });
        sp.setRightComponent(new ClientManagerComponent(jf));
        sp.setLeftComponent(tree);
        jf.add(sp);
        jf.setVisible(true);

    }

    public static void main(String[] args) {
        new ManagerInterface().init();
    }

    private class MyRederer extends DefaultTreeCellRenderer {
        private ImageIcon root = null;
        private ImageIcon userManage = null;
        private ImageIcon intake = null;
        private ImageIcon burned = null;
        private ImageIcon conditions = null;
        private ImageIcon summarize = null;

        public MyRederer() {

            root = new ImageIcon("images/root01.png");
            userManage = new ImageIcon("images/manager01.png");
            intake = new ImageIcon("images/eat01.png");
            burned = new ImageIcon("images/calories01.png");
            conditions = new ImageIcon("images/health01.png");
            summarize = new ImageIcon("images/summarize01.png");
        }

        // Self defined cell renderer
        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
            // Call the superclass method to set up the default renderer
            JLabel label = (JLabel) super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);

            // Add spaces between left
            label.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 5));

            // Set Font be bolded
            label.setFont(label.getFont().deriveFont(Font.BOLD));

            // Set text to white
            label.setForeground(new Color(250, 250, 250));

            ImageIcon image = null;
            switch (row) {
                case 0:
                    image = root;
                    break;
                case 1:
                    image = userManage;
                    break;
                case 2:
                    image = intake;
                    break;
                case 3:
                    image = burned;
                    break;
                case 4:
                    image = conditions;
                    break;
                case 5:
                    image = summarize;
                    break;
            }

            this.setIcon(image);
            return label;
        }
    }
}
