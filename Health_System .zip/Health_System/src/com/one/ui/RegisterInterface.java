package com.one.ui;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Interface of Register
 * Note             : Sub page of registerBtn
 * Date             : 29/03/2024
 */

import com.one.component.BackgroundPanel;
import com.one.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class RegisterInterface {
    JFrame jf = new JFrame("Register");

    final int WIDTH = 500;
    final int HEIGHT = 523;
    private String url = "jdbc:mysql:///Health_Manager?useSSL=false";
    private String username = "root";
    private String pwd = "Wang001128.";
    private Connection conn = null;

    // Assembly frames
    public void init() throws IOException {
        // Get connection
        try {
            conn = DriverManager.getConnection(url, username, pwd);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        // Attribute of frame
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);
        jf.setResizable(false);
        jf.setIconImage(new ImageIcon("images/logo.png").getImage());
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Background
        BackgroundPanel bgPanel = new BackgroundPanel(ImageIO.read(new File("images/background5.jpg")));
        bgPanel.setBounds(0, 0, WIDTH, HEIGHT);

        Box vBox = Box.createVerticalBox();

        // Assembling Client
        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("User Name: ");
        uLabel.setFont(uLabel.getFont().deriveFont(Font.BOLD));
        uLabel.setForeground(new Color(233, 233, 233));
        JTextField uField = new JTextField();
        uLabel.setPreferredSize(new Dimension(100, 30));
        uField.setPreferredSize(new Dimension(230, 30));

        uBox.add(uLabel);
        uBox.add(uField);

        // Assembling Password
        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("Password: ");
        pLabel.setFont(pLabel.getFont().deriveFont(Font.BOLD));
        pLabel.setForeground(new Color(233, 233, 233));
        JTextField pField = new JTextField();
        pLabel.setPreferredSize(new Dimension(100, 30));
        pField.setPreferredSize(new Dimension(230, 30));

        pBox.add(pLabel);
        pBox.add(pField);

        // Assembling Phone Number
        Box tBox = Box.createHorizontalBox();
        JLabel tLabel = new JLabel("Phone Num: ");
        tLabel.setFont(tLabel.getFont().deriveFont(Font.BOLD));
        tLabel.setForeground(new Color(233, 233, 233));
        JTextField tField = new JTextField();
        tLabel.setPreferredSize(new Dimension(100, 30));
        tField.setPreferredSize(new Dimension(230, 30));

        tBox.add(tLabel);
        tBox.add(tField);

        // Assembling Gender
        Box gBox = Box.createHorizontalBox();
        JLabel gLabel = new JLabel("Gender: ");
        gLabel.setFont(gLabel.getFont().deriveFont(Font.BOLD));
        gLabel.setForeground(new Color(233, 233, 233));
        gLabel.setAlignmentY(Component.CENTER_ALIGNMENT);
        gLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JRadioButton maleBtn = new JRadioButton("Male", true);
        JRadioButton femaleBtn = new JRadioButton("Female", false);
        maleBtn.setForeground(new Color(188, 188, 188));
        femaleBtn.setForeground(new Color(188, 188, 188));

        // Only select one
        ButtonGroup bg = new ButtonGroup();
        bg.add(maleBtn);
        bg.add(femaleBtn);

        gBox.add(gLabel);
        gBox.add(Box.createHorizontalGlue());
        gBox.add(maleBtn);
        gBox.add(Box.createHorizontalStrut(25));
        gBox.add(femaleBtn);
        gBox.add(Box.createHorizontalStrut(70));


        // Assembling Verification code
        Box cBox = Box.createHorizontalBox();
        JLabel cLabel = new JLabel("Verify code: ");
        cLabel.setFont(cLabel.getFont().deriveFont(Font.BOLD));
        cLabel.setForeground(new Color(233, 233, 233));
        JTextField cField = new JTextField();
        cLabel.setPreferredSize(new Dimension(100, 30));
        cField.setPreferredSize(new Dimension(230, 30));

        cBox.add(cLabel);
        cBox.add(cField);

        // Assembling Button
        Box btnBox = Box.createHorizontalBox();
        JButton registerBtn = new JButton("Confirm");
        JButton backBtn = new JButton(" Return ");

        registerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get Client information
                String username = uField.getText().trim();
                String password = pField.getText().trim();
                String phone = tField.getText().trim();
                String gender = bg.isSelected(maleBtn.getModel())?maleBtn.getText():femaleBtn.getText();
                String checkCode = cField.getText().trim();

                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                params.put("phone", phone);
                params.put("gender", gender);
                params.put("checkCode", checkCode);

                if (checkCode.equals("0000")) {

                    // Define SQL
                    String sql = "INSERT INTO manager (username, password, phone, gender, checkCode) VALUES (?, ?, ?, ?, ?)";

                    try {
                        // Create pstmt object
                        PreparedStatement pstmt = conn.prepareStatement(sql);
                        pstmt.setString(1, username);
                        pstmt.setString(2, password);
                        pstmt.setString(3, phone);
                        pstmt.setString(4, gender);
                        pstmt.setString(5, checkCode);

                        // Count if inserted
                        int count = pstmt.executeUpdate();
                        if (count > 0) {
                            JOptionPane.showMessageDialog(jf, "Register success, back to main page");
                            try {
                                new MainInterface().init();
                            } catch (IOException ex) {
                                throw new RuntimeException(ex);
                            }
                            // Release resource
                            pstmt.close();
                            conn.close();
                            // Kill current page
                            jf.dispose();
                        } else {
                            JOptionPane.showMessageDialog(jf, "Insert failed");
                        }
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                } else {
                    JOptionPane.showMessageDialog(jf, "Verify code is wrong");
                }
            }
        });

        // Back button
        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Back to main page
                try {
                    new MainInterface().init();
                    jf.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        backBtn.setForeground(new Color(0, 0, 128));
        registerBtn.setForeground(new Color(0, 0, 128));

        btnBox.add(registerBtn);
        btnBox.add(Box.createHorizontalStrut(80));
        btnBox.add(backBtn);

        vBox.add(Box.createVerticalStrut(70));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(tBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(gBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(cBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(btnBox);

        bgPanel.add(vBox);

        jf.add(bgPanel);

        jf.setVisible(true);
    }

    public static void main(String[] args) {
        try {
            new RegisterInterface().init();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
