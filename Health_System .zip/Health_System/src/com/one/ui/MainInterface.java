package com.one.ui;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Interface of Login
 * Date             : 27/03/2024
 */

import com.one.component.BackgroundPanel;
import com.one.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class MainInterface {
    JFrame jf = new JFrame("Health Manager");

    final int WIDTH = 500;
    final int HEIGHT = 333;

    private String url = "jdbc:mysql:///Health_Manager?useSSL=false";
    private String username = "root";
    private String pwd = "Wang001128.";

    private Connection conn = null;

    // Assembly view
    public void init() throws IOException {
        try {
            conn = DriverManager.getConnection(url, username, pwd);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        // Set frame attributes
        jf.setBounds((ScreenUtils.getScreenWidth() - WIDTH) / 2, (ScreenUtils.getScreenHeight() - HEIGHT) / 2, WIDTH, HEIGHT);
        jf.setResizable(false);
        // jf.setIconImage(ImageIO.read(new File(PathUtils.getRealPath("logo.png"))));
        jf.setIconImage(new ImageIcon("images/logo.png").getImage());
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // BackgroundPanel bgPanel = new BackGroundPanel(ImageIO.read(new File(PathUtils.getRealPath("background.png"))))
        BackgroundPanel bgPanel = new BackgroundPanel(ImageIO.read(new File("images/background3.jpg")));

        // Assembling related elements
        Box vBox = Box.createVerticalBox();

        // Assembling user
        Box uBox = Box.createHorizontalBox();
        JLabel uLabel = new JLabel("User Name:");
        uLabel.setFont(uLabel.getFont().deriveFont(Font.BOLD));
        uLabel.setForeground(Color.WHITE);
        JTextField uField = new JTextField();

        uLabel.setPreferredSize(new Dimension(100, 30));
        uField.setPreferredSize(new Dimension(200, 30));

        uBox.add(uLabel);
        uBox.add(uField);

        // Create password
        Box pBox = Box.createHorizontalBox();
        JLabel pLabel = new JLabel("Password:");
        pLabel.setFont(pLabel.getFont().deriveFont(Font.BOLD));
        pLabel.setForeground(Color.WHITE);
        JPasswordField pField = new JPasswordField();
        pLabel.setPreferredSize(new Dimension(100, 30));
        pField.setPreferredSize(new Dimension(200, 30));

        pBox.add(pLabel);
        pBox.add(pField);

        // Create buttons
        Box btnBox = Box.createHorizontalBox();
        JButton loginBtn = new JButton("   Login   ");
        JButton registerBtn = new JButton("Register");

        // Color of button
        loginBtn.setForeground(new Color(0, 0, 128));
        registerBtn.setForeground(new Color(0, 0, 128));

        loginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get user enter data
                String userName = uField.getText().trim();
                String  password = pField.getText().trim();
                Map<String, String> params = new HashMap<>();
                params.put("username", userName);
                params.put("password", password);

                String sql = "SELECT * FROM manager WHERE username = ? AND password = ?";
                try {
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    pstmt.setString(1, userName);
                    pstmt.setString(2, password);
                    ResultSet rs = pstmt.executeQuery();

                    if (rs.next()) {
                        new ManagerInterface().init();
                        jf.dispose();
                        rs.close();
                        pstmt.close();
                        conn.close();
                    } else {
                        JOptionPane.showMessageDialog(jf, "Login Failed");
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        registerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Link to register page
                try {
                    new RegisterInterface().init();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

                // Let current page disappear
                jf.dispose();
            }
        });

        btnBox.add(loginBtn);
        btnBox.add(Box.createHorizontalStrut(100));
        btnBox.add(registerBtn);

        vBox.add(Box.createVerticalStrut(65));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(35));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(55));
        vBox.add(btnBox);

        bgPanel.add(vBox);

        jf.add(bgPanel);
        jf.setVisible(true);

    }

    // Client program entrance
    public static void main(String[] args) {
        try {
            new MainInterface().init();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
