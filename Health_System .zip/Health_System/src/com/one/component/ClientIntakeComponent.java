package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Intake Interface
 * Date             : 11/04/2024
 */

import com.one.domain.Client;
import com.one.domain.ClientDAO;
import com.one.domain.Intake;
import com.one.domain.IntakeDAO;
import com.one.listener.ActionDoneListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;

public class ClientIntakeComponent extends Box {
    final int WIDTH = 1350;
    final int HEIGHT = 750;
    JFrame jf = null;
    private Vector<String> titles;
    private Vector<Vector> tableData;
    private DefaultTableModel tableModel;
    private JTable jTable;
    DefaultTableModel model;

    IntakeDAO intakeDAO = new IntakeDAO();

    public ClientIntakeComponent(JFrame jf) {
        // Vertical layout
        super(BoxLayout.Y_AXIS);

        // Assembling table
        this.jf = jf;
        JPanel btnPanel = new JPanel();
        Color color = new Color(0, 11, 28);
        btnPanel.setBackground(color);
        btnPanel.setMaximumSize(new Dimension(WIDTH, 60));
        btnPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));


        String[] meal = {"", "breakfast", "lunch", "dinner"};
        JComboBox<String> searchField = new JComboBox<String>(meal);
        searchField.setPreferredSize(new Dimension(200, 25));
        JButton searchBtn = new JButton("Search");
        searchBtn.setToolTipText("Search as meal");
        JButton addBtn = new JButton("   Add   ");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");

        // Assembling table
        String[] ts = {"ID", "Name", "Protein", "Weight", "Vegetable", "Weight",
                "Stable", "Weight", "Fat", "Weight", "Calories", "Meal", "Date"};
        titles = new Vector<>();
        for (String title : ts) {
            titles.add(title);
        }
        model = new DefaultTableModel(titles, 0);
        jTable = new JTable(model) {
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };
        // Set can only select one row
        jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane jScrollPane = new JScrollPane(jTable);
        jScrollPane.setBounds(20, 50, 800, 600);
        requestData();

        tableData = new Vector<>();
        tableModel = new DefaultTableModel(tableData, titles);

        searchBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String meal = (String) searchField.getSelectedItem();
                List<Intake> list = intakeDAO.getIntakeBy(meal);
                model.getDataVector().clear();
                for (int i = 0; i < list.size(); i ++) {
                    Intake intake = list.get(i);
                    Object[] rowData = {
                            intake.getId(),
                            intake.getName(),
                            intake.getProtein(),
                            intake.getPWeight(),
                            intake.getVegetable(),
                            intake.getVWeight(),
                            intake.getStableFood(),
                            intake.getSWeight(),
                            intake.getFat(),
                            intake.getFWeight(),
                            intake.getCalories(),
                            intake.getMeal(),
                            intake.getDate()
                    };
                    model.addRow(rowData);
                }
            }
        });

        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Popup window let user add information
                new AddIntakeDialog(jf, "Add Intake", true, new ActionDoneListener() {
                    @Override
                    public void done(Object result) {
                        requestData();
                    }
                }).setVisible(true);
            }
        });

        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get current selected row's id
                int selectedRow = jTable.getSelectedRow();   // If selected, then return id, else return -1
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(jf, "Please select a row to update");
                    return;
                } else {
                    Integer id = (Integer) jTable.getValueAt(selectedRow, 0);
                    new UpdateIntakeDialog(jf, "Update Intake", true, new ActionDoneListener() {
                        @Override
                        public void done(Object result) {
                            requestData();
                        }
                    }, id).setVisible(true);
                }
            }
        });

        deleteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get selected row
                int selectedRow = jTable.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(jf, "Please select a row to delete");
                    return;
                } else {
                    Integer id = (Integer) jTable.getValueAt(selectedRow, 0);
                    int num = JOptionPane.showConfirmDialog(jf, "Confirm Delete", "Remind", JOptionPane.OK_CANCEL_OPTION);
                    if (num == 0) {
                        int ret = intakeDAO.delIntake(id);
                        if (ret > 0) {
                            requestData();
                        }
                    }
                }
            }
        });

        btnPanel.add(searchField);
        btnPanel.add(searchBtn);
        btnPanel.add(Box.createHorizontalStrut(555));
        btnPanel.add(addBtn);
        btnPanel.add(updateBtn);
        btnPanel.add(deleteBtn);
        this.add(btnPanel);
        this.add(jScrollPane);
    }

    // Query data
    public void requestData() {
        // Clear existing data
        model.getDataVector().clear();
        // Get intake data
        List<Intake> intakes= intakeDAO.getIntake();
        // Iterate over clients and add corresponding intake data to the table model
        for (Intake intake : intakes) {
            // Calculate calories for each intake
            intake.setCalories();
            Object[] rowData = {
                    intake.getId(),
                    intake.getName(),
                    intake.getProtein(),
                    intake.getPWeight(),
                    intake.getVegetable(),
                    intake.getVWeight(),
                    intake.getStableFood(),
                    intake.getSWeight(),
                    intake.getFat(),
                    intake.getFWeight(),
                    intake.getCalories(),
                    intake.getMeal(),
                    intake.getDate()
            };
            model.addRow(rowData);
        }
    }
}
