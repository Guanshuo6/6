package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : For the right side of the user interface
 * Date             : 22/04/2024
 */

import com.one.domain.SummarizeDAO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

public class ClientSummarizeComponent extends Box {
    final int WIDTH = 1350;
    final int HEIGHT = 750;
    JFrame jf = null;
    private Vector<String> titles;
    private Vector<Vector> tableData;
    private DefaultTableModel tableModel;
    private JTable jTable;
    private int[] data;
    DefaultTableModel model;
    SummarizeDAO summarizeDAO = new SummarizeDAO();

    public ClientSummarizeComponent(JFrame jf) {
        // Vertical layout
        super(BoxLayout.Y_AXIS);

        // Assembling table
        this.jf = jf;

        JPanel btnPanel = new JPanel();
        Color color = new Color(0, 11, 28);
        btnPanel.setBackground(color);
        btnPanel.setMaximumSize(new Dimension(WIDTH, 40));
        btnPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        String[] table = {"","intake", "calories"};
        JComboBox<String> searchField = new JComboBox<String>(table);
        searchField.setPreferredSize(new Dimension(200, 25));
        JButton searchBtn = new JButton("Search");
        searchBtn.setToolTipText("Search number of clients");

        JPanel chartPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();

                g2d.setStroke(new BasicStroke(2));
                g2d.drawLine(100, 570, 1060, 570);
                g2d.drawLine(100, 570, 100, 50);

                int x = 100;
                String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
                for (String month : months) {
                    g2d.drawString(month, x, 600);
                    x += 85;
                }

                int y = 580;
                String[] yAxis = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"};
                for (String axis : yAxis) {
                    g2d.drawString(axis, 80, y);
                    y -= 35;
                }

                searchBtn.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String table = (String) searchField.getSelectedItem();
                        data = summarizeDAO.getIntakeClient(table);
                        repaint();
                    }
                });

                if (data != null) {
                    g2d.setColor(Color.RED);
                    int scaleX = (getWidth() - 2 * 100) / (data.length - 1);
                    int scaleY = (getHeight() - 2 * 50) / 20;
                    for (int i = 0; i < data.length - 1; i++) {
                        int x1 = 100 + i * scaleX;
                        int y1 = 570 - data[i] * scaleY;
                        int x2 = 100 + (i + 1) * scaleX;
                        int y2 = 570 - data[i + 1] * scaleY;
                        g2d.drawLine(x1, y1, x2, y2);
                    }
                }

                g2d.dispose();
            }
        };

        btnPanel.add(searchField);
        btnPanel.add(searchBtn);
        this.add(btnPanel);
        this.add(chartPanel);
    }

}
