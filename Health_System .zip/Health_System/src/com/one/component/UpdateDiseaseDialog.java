package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Create new info of intake
 * Note             : When create manager should remember client id
 * Date             : 11/04/2024
 */

import com.one.domain.Disease;
import com.one.domain.DiseaseDAO;
import com.one.domain.Intake;
import com.one.listener.ActionDoneListener;
import com.one.util.ScreenUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static java.lang.Integer.parseInt;

public class UpdateDiseaseDialog extends JDialog{
    final int WIDTH = 550;
    final int HEIGHT = 400;

    private JTextField idField;
    private JTextField clientIdField;
    private JComboBox<String> typeField;
    private JTextField startField;
    private JTextField endField;

    private ActionDoneListener listener;

    DiseaseDAO diseaseDAO = new DiseaseDAO();

    public UpdateDiseaseDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener, Integer id) {
        super(jf, title, isModel);
        this.listener = listener;
        // Assembling frame
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);

        Box vBox = Box.createVerticalBox();

        // ID Box
        Box idBox = Box.createHorizontalBox();
        JLabel idLabel = new JLabel("ID:");
        idLabel.setFont(idLabel.getFont().deriveFont(Font.BOLD));
        idField = new JTextField();
        idLabel.setPreferredSize(new Dimension(200, 30));
        idField.setPreferredSize(new Dimension(100 ,30));

        idBox.add(idLabel);
        idBox.add(idField);

        // Assembling Client ID
        Box clientIdBox = Box.createHorizontalBox();
        JLabel clientIdLabel = new JLabel("Client ID:");
        clientIdLabel.setFont(clientIdLabel.getFont().deriveFont(Font.BOLD));
        clientIdField = new JTextField();
        clientIdLabel.setPreferredSize(new Dimension(200, 30));
        clientIdField.setPreferredSize(new Dimension(100, 30));

        clientIdBox.add(clientIdLabel);
        clientIdBox.add(clientIdField);

        // Disease Type
        Box typeBox = Box.createHorizontalBox();
        JLabel typeLabel = new JLabel("Disease Type:");
        typeLabel.setFont(typeLabel.getFont().deriveFont(Font.BOLD));
        String[] typeString = {" ", "cardiovascular", "cancer", "respiratory", "digestive system", "immune system","metabolic", "nervous system", "infectious", "skin", "mental"};
        typeField = new JComboBox<String >(typeString);
        typeLabel.setPreferredSize(new Dimension(200, 30));
        typeField.setPreferredSize(new Dimension(100, 30));

        typeBox.add(typeLabel);
        typeBox.add(typeField);

        // Assembling Start Date
        Box startBox = Box.createHorizontalBox();
        JLabel startLabel = new JLabel("Start Date(DD/MM/YYYY):");
        startLabel.setFont(startLabel.getFont().deriveFont(Font.BOLD));
        startField = new JTextField();
        startLabel.setPreferredSize(new Dimension(200, 30));
        startField.setPreferredSize(new Dimension(100, 30));

        startBox.add(startLabel);
        startBox.add(startField);

        // Assembling End Date
        Box endBox = Box.createHorizontalBox();
        JLabel endLabel = new JLabel("End Date(DD/MM/YYYY):");
        endLabel.setFont(idLabel.getFont().deriveFont(Font.BOLD));
        endField = new JTextField();
        endLabel.setPreferredSize(new Dimension(200, 30));
        endField.setPreferredSize(new Dimension(100, 30));

        endBox.add(endLabel);
        endBox.add(endField);

        Box btnBox = Box.createHorizontalBox();
        JButton updateBtn = new JButton("Update");

        Disease disease = diseaseDAO.getDiseaseBy(id).get(0);
        if (disease != null) {
            idField.setText(disease.getId().toString());
            clientIdField.setText(String.valueOf(disease.getClientId()));
            typeField.setSelectedItem(disease.getDisease());
            startField.setText(disease.getStart());
            endField.setText(disease.getEnd());
        } else {
            System.out.println("Failed to retrieve intake information for ID: " + id);
        }

        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = parseInt(idField.getText());
                int clientId = parseInt(clientIdField.getText());
                String type = (String) typeField.getSelectedItem();
                String start = startField.getText();
                String end = endField.getText();
                Disease disease = new Disease(id, clientId, type, start, end);
                int count = diseaseDAO.updateDisease(disease);
                if (count > 0) {
                    JOptionPane.showMessageDialog(jf, "Update success", "Remind", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    listener.done(null);
                } else {
                    JOptionPane.showMessageDialog(jf, "Update failed", "Remind", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        /*updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = parseInt(idField.getText());
                String type = (String) typeField.getSelectedItem();
                String start = startField.getText();
                String end = endField.getText();
                Disease disease = new Disease(null, id, type, start, end);
                int count = diseaseDAO.addDisease(disease);
                if (count > 0) {
                    JOptionPane.showMessageDialog(jf, "Add success", "Remind", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    listener.done(null);
                } else {
                    JOptionPane.showMessageDialog(jf, "Add failed", "Remind", JOptionPane.INFORMATION_MESSAGE);
                }

            }
        });*/

        btnBox.add(updateBtn);

        vBox.add(Box.createVerticalStrut(45));
        vBox.add(idBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(clientIdBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(typeBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(startBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(endBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(btnBox);
        vBox.add(Box.createVerticalStrut(45));

        // Add spaces for two sides, Add vBox to wrap the Box
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(40)); // Add left spaces
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(40)); // Add right spaces

        this.add(hBox);
    }
}
