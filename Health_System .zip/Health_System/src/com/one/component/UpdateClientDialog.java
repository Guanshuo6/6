package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Update Client information
 * Date             : 01/04/2024
 */

import com.one.domain.Client;
import com.one.domain.ClientDAO;
import com.one.listener.ActionDoneListener;
import com.one.util.ScreenUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

import static java.lang.Integer.parseInt;

public class UpdateClientDialog extends JDialog {

    final int WIDTH = 550;
    final int HEIGHT = 425;
    private Integer id;

    private ActionDoneListener listener;
    private Map<String, Object> map;
    ClientDAO clientDAO = new ClientDAO();
    private JTextField idField;
    private JTextField nameField;
    private JComboBox<String> genderField;
    private JTextField heightField;
    private JTextField weightField;
    private JTextField dobField;
    private JComboBox<String> diseaseField;
    DefaultTableModel model;
    public UpdateClientDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener, int id) {
        super(jf, title, isModel);
        this.listener = listener;
        this.id = id;
        // Assembling frame
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);

        Box vBox = Box.createVerticalBox();

        // Assembling name
        Box idBox = Box.createHorizontalBox();
        JLabel idLabel = new JLabel("id:");
        idLabel.setFont(idLabel.getFont().deriveFont(Font.BOLD));
        idField = new JTextField();
        idLabel.setPreferredSize(new Dimension(100, 30));
        idField.setPreferredSize(new Dimension(200, 30));

        idBox.add(idLabel);
        idBox.add(idField);

        // Assembling name
        Box nameBox = Box.createHorizontalBox();
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(nameLabel.getFont().deriveFont(Font.BOLD));
        nameField = new JTextField();
        nameLabel.setPreferredSize(new Dimension(100, 30));
        nameField.setPreferredSize(new Dimension(200, 30));

        nameBox.add(nameLabel);
        nameBox.add(nameField);

        // Assembling gender
        Box genderBox = Box.createHorizontalBox();
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setFont(genderLabel.getFont().deriveFont(Font.BOLD));
        String[] geString = {" ", "male", "female", "unwilling to say"};
        genderField = new JComboBox<String >(geString);
        genderLabel.setPreferredSize(new Dimension(100, 30));
        genderField.setPreferredSize(new Dimension(300, 30));

        genderBox.add(genderLabel);
        genderBox.add(genderField);

        // Assembling height in cm
        Box heightBox = Box.createHorizontalBox();
        JLabel heightLabel = new JLabel("Height:");
        heightLabel.setFont(heightLabel.getFont().deriveFont(Font.BOLD));
        heightField = new JTextField();
        heightLabel.setPreferredSize(new Dimension(100, 30));
        heightField.setPreferredSize(new Dimension(200, 30));

        heightBox.add(heightLabel);
        heightBox.add(heightField);

        // Assembling weight in kg
        Box weightBox = Box.createHorizontalBox();
        JLabel weightLabel = new JLabel("Weight:");
        weightLabel.setFont(weightLabel.getFont().deriveFont(Font.BOLD));
        weightField = new JTextField();
        weightLabel.setPreferredSize(new Dimension(100, 30));
        weightField.setPreferredSize(new Dimension(200, 30));

        weightBox.add(weightLabel);
        weightBox.add(weightField);

        // Assembling Date of birth DD/MM/YYYY
        Box dobBox = Box.createHorizontalBox();
        JLabel dobLabel = new JLabel("Date of Birth:");
        dobLabel.setFont(dobLabel.getFont().deriveFont(Font.BOLD));
        dobField = new JTextField();
        dobLabel.setPreferredSize(new Dimension(100, 30));
        dobField.setPreferredSize(new Dimension(200, 30));

        dobBox.add(dobLabel);
        dobBox.add(dobField);

        // Assembling Disease(true/false)
        Box diseaseBox = Box.createHorizontalBox();
        JLabel diseaseLabel = new JLabel("Disease:");
        diseaseLabel.setFont(diseaseLabel.getFont().deriveFont(Font.BOLD));
        String [] deString = {" ", "true", "false"};
        diseaseField = new JComboBox<String >(deString);
        diseaseLabel.setPreferredSize(new Dimension(100, 30));
        diseaseField.setPreferredSize(new Dimension(200, 30));

        diseaseBox.add(diseaseLabel);
        diseaseBox.add(diseaseField);

        // Assembling Button
        Box btnBox = Box.createHorizontalBox();
        JButton updateBtn = new JButton("Update");

        Client client = clientDAO.getClientBy(id).get(0);
        if (client != null) {
            idField.setText(client.getId().toString());
            nameField.setText(client.getName());
            genderField.setSelectedItem(client.getGender());
            heightField.setText(client.getHeight());
            weightField.setText(client.getWeight());
            dobField.setText(client.getDob());
            diseaseField.setSelectedItem(client.getDisease());
        } else {
            System.out.println("Failed to retrieve client information for ID: " + id);
        }

        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get client entered input contents
                int id = parseInt(idField.getText());
                String name = nameField.getText();
                String gender = (String) genderField.getSelectedItem();
                String height = heightField.getText();
                String weight = weightField.getText();
                String dob = dobField.getText();
                String disease = (String) diseaseField.getSelectedItem();
                // Get client ID from map
                Client client = new Client(id, name, gender, height, weight, dob, disease);

                // Access interface
                int count = clientDAO.updateClient(client);
                if (count > 0) {
                    JOptionPane.showMessageDialog(jf,"Update success", "Remind", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    listener.done(null);
                } else {
                    JOptionPane.showMessageDialog(jf, "Update failed", "Remind", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        btnBox.add(updateBtn);

        vBox.add(Box.createVerticalStrut(25));
        vBox.add(idBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(nameBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(genderBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(heightBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(weightBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(dobBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(diseaseBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(btnBox);
        vBox.add(Box.createVerticalStrut(25));

        // Add spaces for two sides, Add vBox to wrap the Box
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(40)); // Add left spaces
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(40)); // Add right spaces

        this.add(hBox);

    }
}