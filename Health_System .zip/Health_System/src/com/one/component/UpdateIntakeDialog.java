package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Update Client dialog
 * Date             : 17/04/2024
 */

import com.one.domain.Intake;
import com.one.domain.IntakeDAO;
import com.one.listener.ActionDoneListener;
import com.one.util.ScreenUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static java.lang.Integer.parseInt;

public class UpdateIntakeDialog extends JDialog {
    final int WIDTH = 550;
    final int HEIGHT = 550;

    private Integer id;

    private ActionDoneListener listener;

    IntakeDAO intakeDAO = new IntakeDAO();
    private JTextField idField;
    private JTextField clientIdField;
    private JComboBox<String> proteinField;
    private JTextField pWeightField;
    private JComboBox<String> vegField;
    private JTextField vegWField;
    private JComboBox<String> staField;
    private JTextField staWField;
    private JComboBox<String> fatField;
    private JTextField fatWField;

    private JComboBox<String> mealField;
    private JTextField dateField;
    public UpdateIntakeDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener, int id) {
        super(jf, title, isModel);
        this.listener = listener;
        this.id = id;
        // Assembling frame
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);

        Box vBox = Box.createVerticalBox();

        // Assembling ID
        Box idBox = Box.createHorizontalBox();
        JLabel idLabel = new JLabel("ID:");
        idLabel.setFont(idLabel.getFont().deriveFont(Font.BOLD));
        idField = new JTextField();
        idLabel.setPreferredSize(new Dimension(150, 30));
        idField.setPreferredSize(new Dimension(150, 30));

        idBox.add(idLabel);
        idBox.add(idField);

        // Assembling Client ID
        Box clientIdBox = Box.createHorizontalBox();
        JLabel clientIdLabel = new JLabel("Client ID:");
        clientIdLabel.setFont(clientIdLabel.getFont().deriveFont(Font.BOLD));
        clientIdField = new JTextField();
        clientIdLabel.setPreferredSize(new Dimension(150, 30));
        clientIdField.setPreferredSize(new Dimension(150, 30));

        clientIdBox.add(clientIdLabel);
        clientIdBox.add(clientIdField);

        // Assembling Protein Type
        Box proteinBox = Box.createHorizontalBox();
        JLabel proteinLabel = new JLabel("Main Protein Type:");
        proteinLabel.setFont(proteinLabel.getFont().deriveFont(Font.BOLD));
        String[] proString = {" ", "livestock meat", "poultry", "fish, shrimp .ect", "egg"};
        proteinField = new JComboBox<String >(proString);
        proteinLabel.setPreferredSize(new Dimension(150, 30));
        proteinField.setPreferredSize(new Dimension(150, 30));

        proteinBox.add(proteinLabel);
        proteinBox.add(proteinField);

        // Assembling Protein Weight
        Box pWeightBox = Box.createHorizontalBox();
        JLabel pWeightLabel = new JLabel("Protein Weight (g):");
        pWeightLabel.setFont(pWeightLabel.getFont().deriveFont(Font.BOLD));
        pWeightField = new JTextField();
        pWeightLabel.setPreferredSize(new Dimension(150, 30));
        pWeightField.setPreferredSize(new Dimension(150, 30));

        pWeightBox.add(pWeightLabel);
        pWeightBox.add(pWeightField);

        // Assembling Vegetable Type
        Box vegBox = Box.createHorizontalBox();
        JLabel vegLabel = new JLabel("Main Vegetable Type:");
        vegLabel.setFont(vegLabel.getFont().deriveFont(Font.BOLD));
        String[] vegString = {" ", "root", "leafy", "cabbage", "tomato", "beans"};
        vegField = new JComboBox<String >(vegString);
        vegLabel.setPreferredSize(new Dimension(150, 30));
        vegField.setPreferredSize(new Dimension(150, 30));

        vegBox.add(vegLabel);
        vegBox.add(vegField);

        // Assembling Vegetable Weight
        Box vegWeightBox = Box.createHorizontalBox();
        JLabel vegWLabel = new JLabel("Vegetable Weight (g):");
        vegWLabel.setFont(vegWLabel.getFont().deriveFont(Font.BOLD));
        vegWField = new JTextField();
        vegWLabel.setPreferredSize(new Dimension(150, 30));
        vegWField.setPreferredSize(new Dimension(150, 30));

        vegWeightBox.add(vegWLabel);
        vegWeightBox.add(vegWField);

        // Assembling Vegetable Type
        Box staBox = Box.createHorizontalBox();
        JLabel staLabel = new JLabel("Main Stable Food:");
        staLabel.setFont(staLabel.getFont().deriveFont(Font.BOLD));
        String[] staString = {" ", "maize", "rice", "wheat", "bread", "potato"};
        staField = new JComboBox<String>(staString);
        staLabel.setPreferredSize(new Dimension(150, 30));
        staField.setPreferredSize(new Dimension(150, 30));

        staBox.add(staLabel);
        staBox.add(staField);

        // Assembling Vegetable Weight
        Box staWeightBox = Box.createHorizontalBox();
        JLabel staWLabel = new JLabel("Stable Weight (g):");
        staWLabel.setFont(staWLabel.getFont().deriveFont(Font.BOLD));
        staWField = new JTextField();
        staWLabel.setPreferredSize(new Dimension(150, 30));
        staWField.setPreferredSize(new Dimension(150, 30));

        staWeightBox.add(staWLabel);
        staWeightBox.add(staWField);

        // Assembling Fat Type
        Box fatBox = Box.createHorizontalBox();
        JLabel fatLabel = new JLabel("Main Fat Type:");
        fatLabel.setFont(fatLabel.getFont().deriveFont(Font.BOLD));
        String[] fatString = {" ", "animal fat", "tropical oil", "vegetable oil", "nuts oil", "fish oil"};
        fatField = new JComboBox<String >(fatString);
        fatLabel.setPreferredSize(new Dimension(150, 30));
        fatField.setPreferredSize(new Dimension(150, 30));

        fatBox.add(fatLabel);
        fatBox.add(fatField);

        // Assembling Fat Weight
        Box fatWeightBox = Box.createHorizontalBox();
        JLabel fatWLabel = new JLabel("Fat Weight (g):");
        fatWLabel.setFont(staWLabel.getFont().deriveFont(Font.BOLD));
        fatWField = new JTextField();
        fatWLabel.setPreferredSize(new Dimension(150, 30));
        fatWField.setPreferredSize(new Dimension(150, 30));

        fatWeightBox.add(fatWLabel);
        fatWeightBox.add(fatWField);

        // Assembling Meal
        Box mealBox = Box.createHorizontalBox();
        JLabel mealLabel = new JLabel("Meal:");
        mealLabel.setFont(mealLabel.getFont().deriveFont(Font.BOLD));
        String[] mealString = {" ", "breakfast", "lunch", "dinner"};
        mealField = new JComboBox<String >(mealString);
        mealLabel.setPreferredSize(new Dimension(150, 30));
        mealField.setPreferredSize(new Dimension(150, 30));

        mealBox.add(mealLabel);
        mealBox.add(mealField);

        // Assembling Date
        Box dateBox = Box.createHorizontalBox();
        JLabel dateLabel = new JLabel("Date (DD/MM/YYYY):");
        dateLabel.setFont(dateLabel.getFont().deriveFont(Font.BOLD));
        dateField = new JTextField();
        dateLabel.setPreferredSize(new Dimension(150, 30));
        dateField.setPreferredSize(new Dimension(150, 30));

        dateBox.add(dateLabel);
        dateBox.add(dateField);

        // Assembling Button
        Box btnBox = Box.createHorizontalBox();
        JButton updateBtn = new JButton("Update");

        Intake intake = intakeDAO.getIntakeBy(id).get(0);
        if (intake != null) {
            idField.setText(intake.getId().toString());
            clientIdField.setText(intake.getId().toString());
            proteinField.setSelectedItem(intake.getProtein());
            pWeightField.setText(String.valueOf(intake.getPWeight()));
            vegField.setSelectedItem(intake.getVegetable());
            vegWField.setText(String.valueOf(intake.getVWeight()));
            staField.setSelectedItem(intake.getStableFood());
            staWField.setText(String.valueOf(intake.getSWeight()));
            fatField.setSelectedItem(intake.getFat());
            fatWField.setText(String.valueOf(intake.getFWeight()));
            mealField.setSelectedItem(intake.getMeal());
            dateField.setText(intake.getDate());
        } else {
            System.out.println("Failed to retrieve intake information for ID: " + id);
        }

        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = parseInt(idField.getText());
                int clientId = parseInt(clientIdField.getText());
                String protein = (String) proteinField.getSelectedItem();
                int pWeight = parseInt(pWeightField.getText());
                String vegetable = (String) vegField.getSelectedItem();
                int vWeight = parseInt(vegWField.getText());
                String stable = (String) staField.getSelectedItem();
                int sWeight = parseInt(staWField.getText());
                String fat = (String) fatField.getSelectedItem();
                int fWeight = parseInt(fatWField.getText());
                String meal = (String) mealField.getSelectedItem();
                String date = dateField.getText();
                Intake intake = new Intake(id, clientId, protein, pWeight, vegetable, vWeight, stable, sWeight, fat, fWeight, meal, date);

                int count = intakeDAO.updateIntake(intake);
                if (count > 0) {
                    JOptionPane.showMessageDialog(jf, "Update success", "Remind", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    listener.done(null);
                } else {
                    JOptionPane.showMessageDialog(jf, "Update failed", "Remind", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        btnBox.add(updateBtn);

        vBox.add(Box.createVerticalStrut(15));
        vBox.add(idBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(clientIdBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(proteinBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(pWeightBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(vegBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(vegWeightBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(staBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(staWeightBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(fatBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(fatWeightBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(mealBox);
        vBox.add(Box.createVerticalStrut(10));
        vBox.add(dateBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);
        vBox.add(Box.createVerticalStrut(15));

        // Add spaces for two sides, Add vBox to wrap the Box
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(40)); // Add left spaces
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(40)); // Add right spaces

        this.add(hBox);
    }
}
