package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Disease
 * Date             : 19/04/2024
 */

import com.one.domain.Disease;
import com.one.domain.DiseaseDAO;
import com.one.listener.ActionDoneListener;
import com.one.pop.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;
import java.util.Vector;

public class ClientDiseaseComponent extends Box {
    final int WIDTH = 1350;
    final int HEIGHT = 750;

    JFrame jf = null;
    private Vector<String> titles;
    private Vector<Vector> tableData;
    private DefaultTableModel tableModel;
    private JTable jTable;
    DefaultTableModel model;
    private DiseaseDAO diseaseDAO = new DiseaseDAO();

    public ClientDiseaseComponent(JFrame jf) {
        // Vertical layout
        super(BoxLayout.Y_AXIS);

        // Assembling table
        this.jf = jf;
        JPanel btnPanel = new JPanel();
        Color color = new Color(0, 11, 28);
        btnPanel.setBackground(color);
        btnPanel.setMaximumSize(new Dimension(WIDTH, 60));
        btnPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        String[] type = {" ", "cardiovascular", "cancer", "respiratory", "digestive system", "immune system","metabolic", "nervous system", "infectious", "skin", "mental"};
        JComboBox<String> searchField = new JComboBox<String>(type);
        searchField.setPreferredSize(new Dimension(200, 25));
        JButton searchBtn = new JButton("Search");
        searchBtn.setToolTipText("Disease Suggestion");
        JButton addBtn = new JButton("   Add   ");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");

        // Assembling table
        String[] ts = {"ID", "Name", "Gender", "Height", "Weight", "Date of Birth", "Disease Type", "Start Date", "End Date"};
        titles = new Vector<>();
        for (String title : ts) {
            titles.add(title);
        }
        model = new DefaultTableModel(titles, 0);
        jTable = new JTable(model){
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };
        // Set can only select one row
        jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane jScrollPane = new JScrollPane(jTable);
        jScrollPane.setBounds(20, 50, 800, 600);
        requestData();

        tableData = new Vector<>();
        tableModel = new DefaultTableModel(tableData, titles);

        searchBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Link to pop-pus page
                String selectedType = (String) searchField.getSelectedItem();
                try {
                    switch (selectedType) {
                        case "cardiovascular":
                            new CardiovascularPopUps().init();
                            break;
                        case "cancer":
                            new CancerPopUps().init();
                            break;
                        case "respiratory":
                            new RespiratoryPopUps().init();
                            break;
                        case "digestive system":
                            new DigestivePopUps().init();
                            break;
                        case "immune system":
                            new ImmunePopUps().init();
                            break;
                        case "metabolic":
                            new MetabolicPopUps().init();
                            break;
                        case "nervous system":
                            new NervousPopUps().init();
                            break;
                        case "infectious":
                            new InfectiousPopUps().init();
                            break;
                        case "skin":
                            new SkinPopUps().init();
                            break;
                        case "mental":
                            new MentalPopUps().init();
                            break;
                        default:
                            // Set default as non
                            break;
                    }
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Popup window let user add information
                new AddDiseaseDialog(jf, "Add Disease", true, new ActionDoneListener() {
                    @Override
                    public void done(Object result) {
                        requestData();
                    }
                }).setVisible(true);
            }
        });

        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get current selected row's id
                int selectedRow = jTable.getSelectedRow();   // If selected, then return id, else return -1
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(jf, "Please select a row to update");
                    return;
                } else {
                    Integer id = (Integer) jTable.getValueAt(selectedRow, 0);
                    new UpdateDiseaseDialog(jf, "Update Disease", true, new ActionDoneListener() {
                        @Override
                        public void done(Object result) {
                            requestData();
                        }
                    }, id).setVisible(true);
                }
            }
        });

        deleteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get selected row
                int selectedRow = jTable.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(jf, "Please select a row to delete");
                    return;
                } else {
                    Integer id = (Integer) jTable.getValueAt(selectedRow, 0);
                    int num = JOptionPane.showConfirmDialog(jf, "Confirm Delete", "Remind", JOptionPane.OK_CANCEL_OPTION);
                    if (num == 0) {
                        int ret = diseaseDAO.delDisease(id);
                        if (ret > 0) {
                            requestData();
                        }
                    }
                }
            }
        });

        btnPanel.add(searchField);
        btnPanel.add(searchBtn);
        btnPanel.add(Box.createHorizontalStrut(555));
        btnPanel.add(addBtn);
        btnPanel.add(updateBtn);
        btnPanel.add(deleteBtn);
        this.add(btnPanel);
        this.add(jScrollPane);
    }

    public void requestData() {
        // Get connection
        model.getDataVector().clear();
        List<Disease> list = DiseaseDAO.getDisease();
        for (int i = 0; i < list.size(); i ++) {
            Disease disease = list.get(i);
            Object[] rowData = {
                    disease.getId(),
                    disease.getName(),
                    disease.getGender(),
                    disease.getHeight(),
                    disease.getWeight(),
                    disease.getDob(),
                    disease.getDisease(),
                    disease.getStart(),
                    disease.getEnd()
            };

            model.addRow(rowData);
        }
    }
}
