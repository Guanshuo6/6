package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Create background for login page
 * Date             : 27/03/2024
 */

import javax.swing.*;
import java.awt.*;

public class BackgroundPanel extends JPanel {
    // Announce an image
    private Image backIcon;
    public BackgroundPanel(Image backIcon) {
        this.backIcon = backIcon;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw Background
        g.drawImage(backIcon, 0, 0, this.getWidth(), this.getHeight(), null);

    }
}
