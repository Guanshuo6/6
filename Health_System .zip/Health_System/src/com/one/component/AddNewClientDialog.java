package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Collect more client basic information
 * Date             : 30/03/2024
 */

import com.one.domain.Client;
import com.one.domain.ClientDAO;
import com.one.util.ScreenUtils;
import com.one.listener.ActionDoneListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddNewClientDialog extends JDialog {

    final int WIDTH = 550;
    final int HEIGHT = 405;

    private ActionDoneListener listener;

    ClientDAO clientDAO = new ClientDAO();
    public AddNewClientDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener) {
        super(jf, title, isModel);
        this.listener = listener;
        // Assembling frame
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);

        Box vBox = Box.createVerticalBox();

        // Assembling name
        Box nameBox = Box.createHorizontalBox();
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(nameLabel.getFont().deriveFont(Font.BOLD));
        JTextField nameField = new JTextField();
        nameLabel.setPreferredSize(new Dimension(100, 30));
        nameField.setPreferredSize(new Dimension(200, 30));

        nameBox.add(nameLabel);
        nameBox.add(nameField);

        // Assembling gender
        Box genderBox = Box.createHorizontalBox();
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setFont(genderLabel.getFont().deriveFont(Font.BOLD));
        String[] geString = {" ", "male", "female", "unwilling to say"};
        JComboBox<String> genderField = new JComboBox<String >(geString);
        genderLabel.setPreferredSize(new Dimension(100, 30));
        genderField.setPreferredSize(new Dimension(300, 30));

        genderBox.add(genderLabel);
        genderBox.add(genderField);

        // Assembling height in cm
        Box heightBox = Box.createHorizontalBox();
        JLabel heightLabel = new JLabel("Height:");
        heightLabel.setFont(heightLabel.getFont().deriveFont(Font.BOLD));
        JTextField heightField = new JTextField();
        heightLabel.setPreferredSize(new Dimension(100, 30));
        heightField.setPreferredSize(new Dimension(200, 30));

        heightBox.add(heightLabel);
        heightBox.add(heightField);

        // Assembling weight in kg
        Box weightBox = Box.createHorizontalBox();
        JLabel weightLabel = new JLabel("Weight:");
        weightLabel.setFont(weightLabel.getFont().deriveFont(Font.BOLD));
        JTextField weightField = new JTextField();
        weightLabel.setPreferredSize(new Dimension(100, 30));
        weightField.setPreferredSize(new Dimension(200, 30));

        weightBox.add(weightLabel);
        weightBox.add(weightField);

        // Assembling Date of birth DD/MM/YYYY
        Box dobBox = Box.createHorizontalBox();
        JLabel dobLabel = new JLabel("Date of Birth:");
        dobLabel.setFont(dobLabel.getFont().deriveFont(Font.BOLD));
        JTextField dobField = new JTextField();
        dobLabel.setPreferredSize(new Dimension(100, 30));
        dobField.setPreferredSize(new Dimension(200, 30));

        dobBox.add(dobLabel);
        dobBox.add(dobField);

        // Assembling Disease(true/false)
        Box diseaseBox = Box.createHorizontalBox();
        JLabel diseaseLabel = new JLabel("Disease:");
        diseaseLabel.setFont(diseaseLabel.getFont().deriveFont(Font.BOLD));
        String [] deString = {" ", "true", "false"};
        JComboBox<String> diseaseField = new JComboBox<String >(deString);
        diseaseLabel.setPreferredSize(new Dimension(100, 30));
        diseaseField.setPreferredSize(new Dimension(200, 30));

        diseaseBox.add(diseaseLabel);
        diseaseBox.add(diseaseField);

        // Assembling Button
        Box btnBox = Box.createHorizontalBox();
        JButton addBtn = new JButton("Add");
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String gender = (String) genderField.getSelectedItem();
                String height = heightField.getText();
                String weight = weightField.getText();
                String dob = dobField.getText();
                String disease = (String) diseaseField.getSelectedItem();
                Client client = new Client(null, name, gender, height, weight, dob, disease);

                int count = clientDAO.addClient(client);
                if (count > 0) {
                    JOptionPane.showMessageDialog(jf,"Add success", "Remind", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    listener.done(null);
                } else {
                    JOptionPane.showMessageDialog(jf, "Add failed", "Remind", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        btnBox.add(addBtn);

        vBox.add(Box.createVerticalStrut(25));
        vBox.add(nameBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(genderBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(heightBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(weightBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(dobBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(diseaseBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(btnBox);
        vBox.add(Box.createVerticalStrut(25));

        // Add spaces for two sides, Add vBox to wrap the Box
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(40)); // Add left spaces
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(40)); // Add right spaces

        this.add(hBox);
    }
}