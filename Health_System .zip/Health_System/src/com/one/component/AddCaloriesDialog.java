package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Create new info of intake
 * Note             : Add Client Dialog
 * Date             : 18/04/2024
 */

import com.one.domain.Calories;
import com.one.domain.CaloriesDAO;
import com.one.listener.ActionDoneListener;
import com.one.util.ScreenUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static java.lang.Integer.parseInt;

public class AddCaloriesDialog extends JDialog {
    final int WIDTH = 550;
    final int HEIGHT = 405;

    private ActionDoneListener listener;

    CaloriesDAO caloriesDAO = new CaloriesDAO();
    public AddCaloriesDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener) {
        super(jf, title, isModel);
        this.listener = listener;
        // Assembling frame
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);

        Box vBox = Box.createVerticalBox();

        // Assembling Client ID
        Box idBox = Box.createHorizontalBox();
        JLabel idLabel = new JLabel("Client ID:");
        idLabel.setFont(idLabel.getFont().deriveFont(Font.BOLD));
        JTextField idField = new JTextField();
        idLabel.setPreferredSize(new Dimension(150, 30));
        idField.setPreferredSize(new Dimension(150, 30));

        idBox.add(idLabel);
        idBox.add(idField);

        // Sport Type
        Box soprtTypeBox = Box.createHorizontalBox();
        JLabel sportTypeLabel = new JLabel("Main Sport Type:");
        sportTypeLabel.setFont(sportTypeLabel.getFont().deriveFont(Font.BOLD));
        String[] sportTypeString = {" ", "ride bike", "swim", "soccer", "basketball", "baseball","badminton", "hike"};
        JComboBox<String> sportTypeField = new JComboBox<String >(sportTypeString);
        sportTypeLabel.setPreferredSize(new Dimension(150, 30));
        sportTypeField.setPreferredSize(new Dimension(150, 30));

        soprtTypeBox.add(sportTypeLabel);
        soprtTypeBox.add(sportTypeField);

        // Assembling Sport Time Long
        Box sportTimeBox = Box.createHorizontalBox();
        JLabel sportTimeLabel = new JLabel("Sport Time(min):");
        sportTimeLabel.setFont(sportTimeLabel.getFont().deriveFont(Font.BOLD));
        JTextField sportTimeFiled = new JTextField();
        sportTimeLabel.setPreferredSize(new Dimension(150, 30));
        sportTimeFiled.setPreferredSize(new Dimension(150, 30));

        sportTimeBox.add(sportTimeLabel);
        sportTimeBox.add(sportTimeFiled);

        // Walk steps
        Box stepsBox = Box.createHorizontalBox();
        JLabel stepsLabel = new JLabel("Walk Steps:");
        stepsLabel.setFont(stepsLabel.getFont().deriveFont(Font.BOLD));
        JTextField stepsField = new JTextField();
        stepsLabel.setPreferredSize(new Dimension(150, 30));
        stepsField.setPreferredSize(new Dimension(150, 30));

        stepsBox.add(stepsLabel);
        stepsBox.add(stepsField);

        // Date
        Box dateBox = Box.createHorizontalBox();
        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setFont(dateLabel.getFont().deriveFont(Font.BOLD));
        JTextField dateField = new JTextField();
        dateLabel.setPreferredSize(new Dimension(150, 30));
        dateField.setPreferredSize(new Dimension(150, 30));

        dateBox.add(dateLabel);
        dateBox.add(dateField);

        // Assembling Button
        Box btnBox = Box.createHorizontalBox();
        JButton addBtn = new JButton("Add");
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = parseInt(idField.getText());
                String sportType = (String) sportTypeField.getSelectedItem();
                int sportTime = parseInt(sportTimeFiled.getText());
                int walkSteps = parseInt(stepsField.getText());
                String date = dateField.getText();
                Calories calories = new Calories(null, id, sportType, sportTime, walkSteps, date);

                int count = caloriesDAO.addCalories(calories);
                if (count > 0) {
                    JOptionPane.showMessageDialog(jf, "Add success", "Remind", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    listener.done(null);
                } else {
                    JOptionPane.showMessageDialog(jf, "Add failed", "Remind", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        btnBox.add(addBtn);

        vBox.add(Box.createVerticalStrut(35));
        vBox.add(idBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(soprtTypeBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(sportTimeBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(stepsBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(dateBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(btnBox);
        vBox.add(Box.createVerticalStrut(35));
        btnBox.add(addBtn);

        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(40)); // Add left spaces
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(40)); // Add right spaces

        this.add(hBox);
    }
}
