package com.one.component;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Create new info of intake
 * Note             : Update Client Dialog
 * Date             : 19/04/2024
 */

import com.one.domain.Calories;
import com.one.domain.CaloriesDAO;
import com.one.domain.Intake;
import com.one.listener.ActionDoneListener;
import com.one.util.ScreenUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static java.lang.Integer.parseInt;

public class UpdateCaloriesDialog extends JDialog {
    final int WIDTH = 550;
    final int HEIGHT = 405;
    private CaloriesDAO caloriesDAO = new CaloriesDAO();
    private Integer id;
    private JTextField idField;
    private JTextField clientIdField;
    private JComboBox<String> sportTypeField;
    private JTextField sportTimeFiled;
    private JTextField stepsField;
    private JTextField dateField;
    private ActionDoneListener listener;

    public UpdateCaloriesDialog(JFrame jf, String title, boolean isModel, ActionDoneListener listener, int id) {
        super(jf, title, isModel);
        this.listener = listener;
        this.id = id;
        // Assembling frame
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);

        Box vBox = Box.createVerticalBox();

        // Update ID
        Box idBox = Box.createHorizontalBox();
        JLabel idLabel = new JLabel("ID:");
        idLabel.setFont(idLabel.getFont().deriveFont(Font.BOLD));
        idField = new JTextField();
        idLabel.setPreferredSize(new Dimension(150, 30));
        idField.setPreferredSize(new Dimension(150, 30));

        idBox.add(idLabel);
        idBox.add(idField);

        // Assembling Client ID
        Box clientIdBox = Box.createHorizontalBox();
        JLabel clientIdLabel = new JLabel("Client ID:");
        clientIdLabel.setFont(clientIdLabel.getFont().deriveFont(Font.BOLD));
        clientIdField = new JTextField();
        clientIdLabel.setPreferredSize(new Dimension(150, 30));
        clientIdField.setPreferredSize(new Dimension(150, 30));

        clientIdBox.add(clientIdLabel);
        clientIdBox.add(clientIdField);

        // Assembling Protein Type
        Box sportTypeBox = Box.createHorizontalBox();
        JLabel sportTypeLabel = new JLabel("Main Sport Type:");
        sportTypeLabel.setFont(sportTypeLabel.getFont().deriveFont(Font.BOLD));
        String[] proString = {" ", "ride bike", "swim", "soccer", "basketball", "baseball","badminton", "hike"};
        sportTypeField = new JComboBox<String >(proString);
        sportTypeLabel.setPreferredSize(new Dimension(150, 30));
        sportTypeField.setPreferredSize(new Dimension(150, 30));

        sportTypeBox.add(sportTypeLabel);
        sportTypeBox.add(sportTypeField);

        // Assembling Sport Time
        Box sportTimeBox = Box.createHorizontalBox();
        JLabel sportTimeLabel = new JLabel("Sport Time(min):");
        sportTimeLabel.setFont(sportTimeLabel.getFont().deriveFont(Font.BOLD));
        sportTimeFiled = new JTextField();
        sportTimeLabel.setPreferredSize(new Dimension(150, 30));
        sportTimeFiled.setPreferredSize(new Dimension(150, 30));

        sportTimeBox.add(sportTimeLabel);
        sportTimeBox.add(sportTimeFiled);

        // Walk Step
        Box stepsBox = Box.createHorizontalBox();
        JLabel stepsLabel = new JLabel("Walk Steps:");
        stepsLabel.setFont(stepsLabel.getFont().deriveFont(Font.BOLD));
        stepsField = new JTextField();
        stepsLabel.setPreferredSize(new Dimension(150, 30));
        stepsField.setPreferredSize(new Dimension(150, 30));

        stepsBox.add(stepsLabel);
        stepsBox.add(stepsField);

        // Walk Step
        Box dateBox = Box.createHorizontalBox();
        JLabel dateLabel = new JLabel("Walk Steps:");
        dateLabel.setFont(dateLabel.getFont().deriveFont(Font.BOLD));
        dateField = new JTextField();
        dateLabel.setPreferredSize(new Dimension(150, 30));
        dateField.setPreferredSize(new Dimension(150, 30));

        dateBox.add(dateLabel);
        dateBox.add(dateField);

        // Assembling Button
        Box btnBox = Box.createHorizontalBox();
        JButton updateBtn = new JButton("Update");

        Calories calories = caloriesDAO.getCaloriesBy(id).get(0);
        if (calories != null) {
            idField.setText(calories.getId().toString());
            clientIdField.setText(String.valueOf(calories.getClientId()));
            sportTypeField.setSelectedItem(calories.getSportType());
            sportTimeFiled.setText(String.valueOf(calories.getSportTime()));
            stepsField.setText(String.valueOf(calories.getWalkSteps()));
            dateField.setText(calories.getDate());
        } else {
            System.out.println("Failed to retrieve intake information for ID: " + id);
        }

        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = parseInt(idField.getText());
                int clientId = parseInt(clientIdField.getText());
                String sportType = (String) sportTypeField.getSelectedItem();
                int sportTime = parseInt(sportTimeFiled.getText());
                int walkSteps = parseInt(stepsField.getText());
                String date = dateField.getText();
                Calories calories = new Calories(id, clientId, sportType, sportTime, walkSteps, date);

                int count = caloriesDAO.updateCalories(calories);
                if (count > 0) {
                    JOptionPane.showMessageDialog(jf, "Update success", "Remind", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    listener.done(null);
                } else {
                    JOptionPane.showMessageDialog(jf, "Update failed", "Remind", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        btnBox.add(updateBtn);

        vBox.add(Box.createVerticalStrut(30));
        vBox.add(idBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(clientIdBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(sportTypeBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(sportTimeBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(stepsBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(dateBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(btnBox);
        vBox.add(Box.createVerticalStrut(30));
        btnBox.add(updateBtn);

        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(40)); // Add left spaces
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(40)); // Add right spaces

        this.add(hBox);
    }
}
