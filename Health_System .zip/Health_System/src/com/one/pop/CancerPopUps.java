package com.one.pop;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Disease Pop-ups
 * Date             : 20/04/2024
 */

import com.one.component.BackgroundPanel;
import com.one.component.ClientDiseaseComponent;
import com.one.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class CancerPopUps {
    JFrame jf = new JFrame("Cancer");
    final int WIDTH = 400;
    final int HEIGHT = 600;
    public void init() throws IOException {
        // Attribute of frame
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);
        jf.setResizable(false);

        // Background
        BackgroundPanel bgPanel = new BackgroundPanel(ImageIO.read(new File("images/bg2.jpg")));

        JLabel label = new JLabel("<html><h3>Suggestion</h3></html>");
        label.setBounds(50, 20, 300, 30);
        bgPanel.add(label);

        JLabel suggestion1 = new JLabel("<html><p style='width:300px'>1. Good eating habits:</p></html>");
        suggestion1.setBounds(50, 50, 300, 25);
        bgPanel.add(suggestion1);

        JLabel sub1 = new JLabel("<html><p style='width:300px'>Diet is very important in the recovery and <br>treatment of cancer patients. It is <br>recommended to eat plenty of fresh vegetables, fruits, whole grains, high-protein foods, and healthy fat sources such as olive oil and fish oil. Avoid too much processed food, sugar, and saturated fat.</p></html>");
        sub1.setBounds(50, 70, 300, 90);
        bgPanel.add(sub1);

        JLabel suggestion2 = new JLabel("<html><p style='width:300px'>2. Maintain a healthy weight:</p></html>");
        suggestion2.setBounds(50, 165, 300, 25);
        bgPanel.add(suggestion2);

        JLabel sub2 = new JLabel("<html><p style='width:300px'>Maintaining an appropriate weight can help <br>improve immune system function and reduce <br>the risk of cancer recurrence.</p></html>");
        sub2.setBounds(50, 165, 300, 80);
        bgPanel.add(sub2);

        JLabel suggestion3 = new JLabel("<html><p style='width:300px'>3. Regular exercise:</p></html>");
        suggestion3.setBounds(50, 230, 300, 25);
        bgPanel.add(suggestion3);

        JLabel sub3 = new JLabel("<html><p style='width:300px'>Moderate physical exercise can help improve <br>the body’s immunity and cardiovascular health, <br>and reduce the risk of cancer.</p></html>");
        sub3.setBounds(50, 235, 300, 80);
        bgPanel.add(sub3);

        JLabel suggestion4 = new JLabel("<html><p style='width:300px'>4. Quitting smoking and limiting alcohol:</p></html>");
        suggestion4.setBounds(50, 300, 300, 25);
        bgPanel.add(suggestion4);

        JLabel sub4 = new JLabel("<html><p style='width:300px'>Quitting smoking and limiting alcohol <br>consumption are important steps in preventing <br>cancer.</p></html>");
        sub4.setBounds(50, 305, 300, 75);
        bgPanel.add(sub4);

        JLabel suggestion5 = new JLabel("<html><p style='width:300px'>5. Regular examinations and treatment as <br>prescribed by the doctor:</p></html>");
        suggestion5.setBounds(50, 375, 300, 30);
        bgPanel.add(suggestion5);

        JLabel sub5 = new JLabel("<html><p style='width:300px'>Cancer patients need to have regular physical <br>examinations and follow the treatment as <br>prescribed by the doctor. Pay close attention to your physical condition and detect and handle abnormalities <br>promptly.</p></html>");
        sub5.setBounds(50, 405, 300, 80);
        bgPanel.add(sub5);

        JButton backBtn = new JButton(" Return ");

        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Back to main page
                try {
                    new ClientDiseaseComponent(jf);
                    jf.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });


        backBtn.setBounds(150, 500, 100, 30);
        bgPanel.add(backBtn);
        bgPanel.setLayout(null);

        jf.add(bgPanel);
        jf.setVisible(true);
    }
}
