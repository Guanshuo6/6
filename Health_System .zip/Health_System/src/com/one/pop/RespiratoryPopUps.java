package com.one.pop;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Disease Pop-ups
 * Date             : 20/04/2024
 */

import com.one.component.BackgroundPanel;
import com.one.component.ClientDiseaseComponent;
import com.one.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class RespiratoryPopUps {
    JFrame jf = new JFrame("Respiratory");
    final int WIDTH = 400;
    final int HEIGHT = 600;
    public void init() throws IOException {
        // Attribute of frame
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);
        jf.setResizable(false);

        // Background
        BackgroundPanel bgPanel = new BackgroundPanel(ImageIO.read(new File("images/bg3.jpg")));

        JLabel label = new JLabel("<html><h3>Suggestion</h3></html>");
        label.setBounds(50, 20, 300, 30);
        bgPanel.add(label);

        JLabel suggestion1 = new JLabel("<html><p style='width:300px'>1. Quit smoking:</p></html>");
        suggestion1.setBounds(50, 50, 300, 25);
        bgPanel.add(suggestion1);

        JLabel sub1 = new JLabel("<html><p style='width:300px'>For smokers, quitting smoking is the first <br>step in preventing and managing respiratory <br>disease. Smoking is one of the leading causes <br>of many respiratory problems.</p></html>");
        sub1.setBounds(50, 60, 300, 90);
        bgPanel.add(sub1);

        JLabel suggestion2 = new JLabel("<html><p style='width:300px'>2. Avoid second-hand smoke:</p></html>");
        suggestion2.setBounds(50, 140, 300, 25);
        bgPanel.add(suggestion2);

        JLabel sub2 = new JLabel("<html><p style='width:300px'>Try to avoid exposure to second-hand smoke <br>as it can also cause damage to the respiratory <br>system.</p></html>");
        sub2.setBounds(50, 140, 300, 80);
        bgPanel.add(sub2);

        JLabel suggestion3 = new JLabel("<html><p style='width:300px'>3. Keep indoor air fresh:</p></html>");
        suggestion3.setBounds(50, 210, 300, 25);
        bgPanel.add(suggestion3);

        JLabel sub3 = new JLabel("<html><p style='width:300px'>ventilate regularly, use an air purifier, and try to <br>avoid indoor pollutants such as dust, pollen, <br>etc.</p></html>");
        sub3.setBounds(50, 215, 300, 80);
        bgPanel.add(sub3);

        JLabel suggestion4 = new JLabel("<html><p style='width:300px'>4. Avoid allergens:</p></html>");
        suggestion4.setBounds(50, 280, 300, 25);
        bgPanel.add(suggestion4);

        JLabel sub4 = new JLabel("<html><p style='width:300px'>For respiratory diseases caused by allergens, <br>such as asthma and allergic rhinitis, try to <br>avoid contact with allergens, such as pollen, <br>dust mites, pet hair, etc.</p></html>");
        sub4.setBounds(50, 290, 300, 75);
        bgPanel.add(sub4);

        JLabel suggestion5 = new JLabel("<html><p style='width:300px'>5. Regular exercise:</p></html>");
        suggestion5.setBounds(50, 360, 300, 30);
        bgPanel.add(suggestion5);

        JLabel sub5 = new JLabel("<html><p style='width:300px'>Moderate exercise can help enhance respiratory <br>system function and immunity, such as <br>walking, jogging, swimming, etc.</p></html>");
        sub5.setBounds(50, 365, 300, 80);
        bgPanel.add(sub5);

        JButton backBtn = new JButton(" Return ");

        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Back to main page
                try {
                    new ClientDiseaseComponent(jf);
                    jf.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });


        backBtn.setBounds(150, 500, 100, 30);
        bgPanel.add(backBtn);
        bgPanel.setLayout(null);

        jf.add(bgPanel);
        jf.setVisible(true);
    }
}
