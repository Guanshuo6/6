package com.one.pop;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Disease Pop-ups
 * Date             : 20/04/2024
 */

import com.one.component.BackgroundPanel;
import com.one.component.ClientDiseaseComponent;
import com.one.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class NervousPopUps {
    JFrame jf = new JFrame("Nervous");
    final int WIDTH = 400;
    final int HEIGHT = 600;
    public void init() throws IOException {
        // Attribute of frame
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);
        jf.setResizable(false);

        // Background
        BackgroundPanel bgPanel = new BackgroundPanel(ImageIO.read(new File("images/bg7.jpg")));

        JLabel label = new JLabel("<html><h3>Suggestion</h3></html>");
        label.setBounds(50, 20, 300, 30);
        bgPanel.add(label);

        JLabel suggestion1 = new JLabel("<html><p style='width:300px'>1. Regular sleep routine:</p></html>");
        suggestion1.setBounds(50, 50, 300, 25);
        bgPanel.add(suggestion1);

        JLabel sub1 = new JLabel("<html><p style='width:300px'>Maintaining good sleep habits and adequate <br>sleep time every night will help improve the <br>stability and recovery ability of the nervous <br>system.</p></html>");
        sub1.setBounds(50, 60, 300, 90);
        bgPanel.add(sub1);

        JLabel suggestion2 = new JLabel("<html><p style='width:300px'>2. Reduce stress:</p></html>");
        suggestion2.setBounds(50, 145, 300, 25);
        bgPanel.add(suggestion2);

        JLabel sub2 = new JLabel("<html><p style='width:300px'>Learn to manage stress and emotions <br>effectively and release stress through healthy <br>ways, such as exercise, meditation, breathing <br>exercises, and art creation.</p></html>");
        sub2.setBounds(50, 160, 300, 80);
        bgPanel.add(sub2);

        JLabel suggestion3 = new JLabel("<html><p style='width:300px'>3. Eat a healthy diet:</p></html>");
        suggestion3.setBounds(50, 240, 300, 25);
        bgPanel.add(suggestion3);

        JLabel sub3 = new JLabel("<html><p style='width:300px'>Eat a balanced diet that includes plenty of <br>vegetables, fruits, whole grains, and healthy fats while cutting back on processed foods, sugar, and <br>caffeine.</p></html>");
        sub3.setBounds(50, 255, 300, 80);
        bgPanel.add(sub3);

        JLabel suggestion4 = new JLabel("<html><p style='width:300px'>4. Avoid over stimulation:</p></html>");
        suggestion4.setBounds(50, 330, 300, 25);
        bgPanel.add(suggestion4);

        JLabel sub4 = new JLabel("<html><p style='width:300px'>Try to avoid prolonged exposure to noisy, <br>brightly lit or other stimulating environments, <br>and keep your body and mind relaxed.</p></html>");
        sub4.setBounds(50, 340, 300, 75);
        bgPanel.add(sub4);

        JLabel suggestion5 = new JLabel("<html><p style='width:300px'>5. Seek support:</p></html>");
        suggestion5.setBounds(50, 405, 300, 30);
        bgPanel.add(suggestion5);

        JLabel sub5 = new JLabel("<html><p style='width:300px'>If necessary, you can seek professional <br>psychological counseling or therapeutic help to <br>obtain better emotional support and regulation.</p></html>");
        sub5.setBounds(50, 415, 300, 80);
        bgPanel.add(sub5);

        JButton backBtn = new JButton(" Return ");

        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Back to main page
                try {
                    new ClientDiseaseComponent(jf);
                    jf.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });


        backBtn.setBounds(150, 500, 100, 30);
        bgPanel.add(backBtn);
        bgPanel.setLayout(null);

        jf.add(bgPanel);
        jf.setVisible(true);
    }
}
