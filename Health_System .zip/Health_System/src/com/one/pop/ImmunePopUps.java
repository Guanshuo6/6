package com.one.pop;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Disease Pop-ups
 * Date             : 20/04/2024
 */

import com.one.component.BackgroundPanel;
import com.one.component.ClientDiseaseComponent;
import com.one.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class ImmunePopUps {
    JFrame jf = new JFrame("Immune");
    final int WIDTH = 400;
    final int HEIGHT = 600;
    public void init() throws IOException {
        // Attribute of frame
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);
        jf.setResizable(false);

        // Background
        BackgroundPanel bgPanel = new BackgroundPanel(ImageIO.read(new File("images/bg5.jpg")));

        JLabel label = new JLabel("<html><h3>Suggestion</h3></html>");
        label.setBounds(50, 20, 300, 30);
        bgPanel.add(label);

        JLabel suggestion1 = new JLabel("<html><p style='width:300px'>1. Eat a healthy diet:</p></html>");
        suggestion1.setBounds(50, 50, 300, 25);
        bgPanel.add(suggestion1);

        JLabel sub1 = new JLabel("<html><p style='width:300px'>Eat plenty of fruits, vegetables, whole grains, <br>healthy fats and protein to provide adequate <br>nutrients and antioxidants.</p></html>");
        sub1.setBounds(50, 50, 300, 90);
        bgPanel.add(sub1);

        JLabel suggestion2 = new JLabel("<html><p style='width:300px'>2. Exercise:</p></html>");
        suggestion2.setBounds(50, 125, 300, 25);
        bgPanel.add(suggestion2);

        JLabel sub2 = new JLabel("<html><p style='width:300px'>Moderate physical activity helps improve <br>immune system function and can help with <br>weight management and stress reduction.\n" +
                "Get <br>enough sleep: Sleep is essential for the proper <br>functioning of your immune system. Make sure you get enough sleep every night.</p></html>");
        sub2.setBounds(50, 145, 300, 95);
        bgPanel.add(sub2);

        JLabel suggestion3 = new JLabel("<html><p style='width:300px'>3. Reduce stress:</p></html>");
        suggestion3.setBounds(50, 245, 300, 25);
        bgPanel.add(suggestion3);

        JLabel sub3 = new JLabel("<html><p style='width:300px'>Chronic stress can weaken the immune system, so learning stress-reduction techniques like meditation, <br>deep breathing, or gentle exercise is crucial to <br>maintaining a healthy immune system.</p></html>");
        sub3.setBounds(50, 255, 300, 80);
        bgPanel.add(sub3);

        JLabel suggestion4 = new JLabel("<html><p style='width:300px'>4. Avoid tobacco and limit alcohol:</p></html>");
        suggestion4.setBounds(50, 335, 300, 25);
        bgPanel.add(suggestion4);

        JLabel sub4 = new JLabel("<html><p style='width:300px'>Tobacco and excessive alcohol intake weaken <br>the immune system.\n" +
                "Maintain a healthy weight: <br>Obesity may affect the function of your <br>immune system. Maintain a healthy weight <br>through a healthy diet and moderate exercise.</p></html>");
        sub4.setBounds(50, 355, 300, 80);
        bgPanel.add(sub4);

        JButton backBtn = new JButton(" Return ");

        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Back to main page
                try {
                    new ClientDiseaseComponent(jf);
                    jf.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });


        backBtn.setBounds(150, 500, 100, 30);
        bgPanel.add(backBtn);
        bgPanel.setLayout(null);

        jf.add(bgPanel);
        jf.setVisible(true);
    }
}
