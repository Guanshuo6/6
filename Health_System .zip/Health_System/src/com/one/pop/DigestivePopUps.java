package com.one.pop;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Disease Pop-ups
 * Date             : 20/04/2024
 */

import com.one.component.BackgroundPanel;
import com.one.component.ClientDiseaseComponent;
import com.one.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class DigestivePopUps {
    JFrame jf = new JFrame("Digestive");
    final int WIDTH = 400;
    final int HEIGHT = 600;
    public void init() throws IOException {
        // Attribute of frame
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);
        jf.setResizable(false);

        // Background
        BackgroundPanel bgPanel = new BackgroundPanel(ImageIO.read(new File("images/bg4.jpg")));

        JLabel label = new JLabel("<html><h3>Suggestion</h3></html>");
        label.setBounds(50, 20, 300, 30);
        bgPanel.add(label);

        JLabel suggestion1 = new JLabel("<html><p style='width:300px'>1. Healthy diet:</p></html>");
        suggestion1.setBounds(50, 50, 300, 25);
        bgPanel.add(suggestion1);

        JLabel sub1 = new JLabel("<html><p style='width:300px'>Maintain a balanced diet that includes fiber-<br>rich fruits, vegetables, whole grains and high-<br>quality protein. Avoid high-fat, high-sugar and <br>processed foods, and reduce your intake of <br>fried foods.</p></html>");
        sub1.setBounds(50, 65, 300, 90);
        bgPanel.add(sub1);

        JLabel suggestion2 = new JLabel("<html><p style='width:300px'>2. Drink plenty of water:</p></html>");
        suggestion2.setBounds(50, 150, 300, 25);
        bgPanel.add(suggestion2);

        JLabel sub2 = new JLabel("<html><p style='width:300px'>Maintaining adequate fluid intake helps digestion and detoxification, and prevents constipation and other digestive problems.</p></html>");
        sub2.setBounds(50, 155, 300, 80);
        bgPanel.add(sub2);

        JLabel suggestion3 = new JLabel("<html><p style='width:300px'>3. Eat regular meals:</p></html>");
        suggestion3.setBounds(50, 225, 300, 25);
        bgPanel.add(suggestion3);

        JLabel sub3 = new JLabel("<html><p style='width:300px'>Maintain regular eating habits to avoid <br>excessive hunger or overeating. Try to avoid eating large amounts before going to bed to avoid affecting digestion.</p></html>");
        sub3.setBounds(50, 230, 300, 80);
        bgPanel.add(sub3);

        JLabel suggestion4 = new JLabel("<html><p style='width:300px'>4. Avoid excessive alcohol consumption:</p></html>");
        suggestion4.setBounds(50, 300, 300, 25);
        bgPanel.add(suggestion4);

        JLabel sub4 = new JLabel("<html><p style='width:300px'>Excessive alcohol consumption can cause <br>damage to the digestive system and increase <br>the risk of digestive system diseases such as <br>gastric ulcers and liver disease.</p></html>");
        sub4.setBounds(50, 315, 300, 75);
        bgPanel.add(sub4);

        JLabel suggestion5 = new JLabel("<html><p style='width:300px'>5. Quit smoking:</p></html>");
        suggestion5.setBounds(50, 385, 300, 30);
        bgPanel.add(suggestion5);

        JLabel sub5 = new JLabel("<html><p style='width:300px'>Smoking increases the risk of gastrointestinal <br>cancer and other digestive problems, so <br>quitting smoking is critical to protecting <br>digestive health.</p></html>");
        sub5.setBounds(50, 400, 300, 80);
        bgPanel.add(sub5);

        JButton backBtn = new JButton(" Return ");

        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Back to main page
                try {
                    new ClientDiseaseComponent(jf);
                    jf.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });


        backBtn.setBounds(150, 500, 100, 30);
        bgPanel.add(backBtn);
        bgPanel.setLayout(null);

        jf.add(bgPanel);
        jf.setVisible(true);
    }

}
