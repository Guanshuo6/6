package com.one.pop;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Disease Pop-ups
 * Date             : 20/04/2024
 */

import com.one.component.BackgroundPanel;
import com.one.component.ClientDiseaseComponent;
import com.one.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class InfectiousPopUps {
    JFrame jf = new JFrame("Infectious");
    final int WIDTH = 400;
    final int HEIGHT = 600;
    public void init() throws IOException {
        // Attribute of frame
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);
        jf.setResizable(false);

        // Background
        BackgroundPanel bgPanel = new BackgroundPanel(ImageIO.read(new File("images/bg8.jpg")));

        JLabel label = new JLabel("<html><h3>Suggestion</h3></html>");
        label.setBounds(50, 20, 300, 30);
        bgPanel.add(label);

        JLabel suggestion1 = new JLabel("<html><p style='width:300px'>1. Wash your hands frequently:</p></html>");
        suggestion1.setBounds(50, 50, 300, 25);
        bgPanel.add(suggestion1);

        JLabel sub1 = new JLabel("<html><p style='width:300px'>Keeping your hands clean is an essential step <br>in preventing infection. Wash your hands <br>thoroughly with soap and water for at least 20 <br>seconds, especially after handling food, <br>touching your face, using the restroom, and <br>after contact with someone who is sick.</p></html>");
        sub1.setBounds(50, 75, 300, 90);
        bgPanel.add(sub1);

        JLabel suggestion2 = new JLabel("<html><p style='width:300px'>2. Avoid contact with sources of infection:</p></html>");
        suggestion2.setBounds(50, 175, 300, 25);
        bgPanel.add(suggestion2);

        JLabel sub2 = new JLabel("<html><p style='width:300px'>Try to avoid contact with people who are <br>infected, especially if they are showing <br>symptoms. Maintain social distance and try to <br>avoid crowded places.</p></html>");
        sub2.setBounds(50, 190, 300, 80);
        bgPanel.add(sub2);

        JLabel suggestion3 = new JLabel("<html><p style='width:300px'>3. Strengthen immunity:</p></html>");
        suggestion3.setBounds(50, 270, 300, 25);
        bgPanel.add(suggestion3);

        JLabel sub3 = new JLabel("<html><p style='width:300px'>Maintaining good living habits, including <br>healthy eating, adequate sleep, moderate <br>exercise, stress reduction, etc., can help <br>improve immunity and reduce the risk of <br>infection.</p></html>");
        sub3.setBounds(50, 295, 300, 80);
        bgPanel.add(sub3);

        JLabel suggestion4 = new JLabel("<html><p style='width:300px'>4. Regular cleaning and disinfection:</p></html>");
        suggestion4.setBounds(50, 380, 300, 25);
        bgPanel.add(suggestion4);

        JLabel sub4 = new JLabel("<html><p style='width:300px'>Regular cleaning and disinfection of frequently <br>touched surfaces, such as door handles, <br>tabletops, mobile phones, etc., can effectively <br>reduce the risk of infection.</p></html>");
        sub4.setBounds(50, 400, 300, 75);
        bgPanel.add(sub4);

        JButton backBtn = new JButton(" Return ");

        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Back to main page
                try {
                    new ClientDiseaseComponent(jf);
                    jf.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });


        backBtn.setBounds(150, 500, 100, 30);
        bgPanel.add(backBtn);
        bgPanel.setLayout(null);

        jf.add(bgPanel);
        jf.setVisible(true);
    }
}
