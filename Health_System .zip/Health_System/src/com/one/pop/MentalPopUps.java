package com.one.pop;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Disease Pop-ups
 * Date             : 20/04/2024
 */

import com.one.component.BackgroundPanel;
import com.one.component.ClientDiseaseComponent;
import com.one.util.ScreenUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class MentalPopUps {
    JFrame jf = new JFrame("Mental");
    final int WIDTH = 400;
    final int HEIGHT = 600;
    public void init() throws IOException {
        // Attribute of frame
        jf.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2, (ScreenUtils.getScreenHeight()-HEIGHT)/2, WIDTH, HEIGHT);
        jf.setResizable(false);

        // Background
        BackgroundPanel bgPanel = new BackgroundPanel(ImageIO.read(new File("images/bg10.jpg")));

        JLabel label = new JLabel("<html><h3>Suggestion</h3></html>");
        label.setBounds(50, 20, 300, 30);
        bgPanel.add(label);

        JLabel suggestion1 = new JLabel("<html><p style='width:300px'>1. Exercise regularly:</p></html>");
        suggestion1.setBounds(50, 50, 300, 25);
        bgPanel.add(suggestion1);

        JLabel sub1 = new JLabel("<html><p style='width:300px'>Moderate physical activity can stimulate the <br>body's secretion of \"happy hormones\" <br>endorphins, reduce symptoms of anxiety and <br>depression, and improve self-esteem.</p></html>");
        sub1.setBounds(50, 60, 300, 90);
        bgPanel.add(sub1);

        JLabel suggestion2 = new JLabel("<html><p style='width:300px'>2. Stay socially connected:</p></html>");
        suggestion2.setBounds(50, 160, 300, 25);
        bgPanel.add(suggestion2);

        JLabel sub2 = new JLabel("<html><p style='width:300px'>Stay connected with family, friends, and <br>community to share feelings and experiences <br>and build a support system.</p></html>");
        sub2.setBounds(50, 170, 300, 80);
        bgPanel.add(sub2);

        JLabel suggestion3 = new JLabel("<html><p style='width:300px'>3. Maintain an optimistic attitude:</p></html>");
        suggestion3.setBounds(50, 255, 300, 25);
        bgPanel.add(suggestion3);

        JLabel sub3 = new JLabel("<html><p style='width:300px'>A positive and optimistic attitude can help you <br>cope with the challenges and difficulties in life <br>and improve your ability to resist frustration.</p></html>");
        sub3.setBounds(50, 265, 300, 80);
        bgPanel.add(sub3);

        JButton backBtn = new JButton(" Return ");

        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Back to main page
                try {
                    new ClientDiseaseComponent(jf);
                    jf.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });


        backBtn.setBounds(150, 500, 100, 30);
        bgPanel.add(backBtn);
        bgPanel.setLayout(null);

        jf.add(bgPanel);
        jf.setVisible(true);
    }
}
