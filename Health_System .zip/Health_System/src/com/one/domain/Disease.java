package com.one.domain;

public class Disease {
    private Integer id;
    private int clientId;
    private String name;
    private String gender;
    private String height;
    private String weight;
    private String dob;
    private String disease;
    private String start;
    private String end;

    public Disease() {

    }

    public Disease(Integer id, int clientId, String disease, String start, String end) {
        this.id = id;
        this.clientId = clientId;
        this.disease = disease;
        this.start = start;
        this.end = end;
    }

    public Disease(Integer id, String name, String gender, String height, String weight, String dob, String disease, String start, String end) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.height = height;
        this.weight = weight;
        this.dob = dob;
        this.disease = disease;
        this.start = start;
        this.end = end;
    }

    public Disease(Integer id, int clientId, String gender, String height, String weight, String dob, String disease, String start, String end) {
        this.id = id;
        this.clientId = clientId;
        this.gender = gender;
        this.height = height;
        this.weight = weight;
        this.dob = dob;
        this.disease = disease;
        this.start = start;
        this.end = end;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }
}
