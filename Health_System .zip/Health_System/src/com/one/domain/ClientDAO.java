package com.one.domain;

import com.one.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Manage client info as require
 * Date             : 08/04/2024
 */

public class ClientDAO {
    public List<Client> getClients() {
        String sql = "SELECT * FROM client";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Client> list = new ArrayList<Client>();
        try {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String gender = rs.getString("gender");
                String height = rs.getString("height");
                String weight = rs.getString("weight");
                String dob = rs.getString("dob");
                String disease = rs.getString("disease");
                Client client = new Client(id, name, gender, height, weight, dob, disease);
                list.add(client);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public List<Client> getClientBy(String clientName) {
        String sql = "SELECT * FROM client WHERE name LIKE ? ";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Client> list = new ArrayList<Client>();
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, "%" + clientName + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                Integer id = rs.getInt("id");
                String name = rs.getString("name");
                String gender = rs.getString("gender");
                String height = rs.getString("height");
                String weight = rs.getString("weight");
                String dob = rs.getString("dob");
                String disease = rs.getString("disease");
                Client client = new Client(id, name, gender, height, weight, dob, disease);
                list.add(client);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public List<Client> getClientBy(int clientId) {
        String sql = "SELECT * FROM client WHERE id = ? ";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Client> list = new ArrayList<Client>();
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, clientId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String gender = rs.getString("gender");
                String height = rs.getString("height");
                String weight = rs.getString("weight");
                String dob = rs.getString("dob");
                String disease = rs.getString("disease");
                Client client = new Client(id, name, gender, height, weight, dob, disease);
                list.add(client);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public int delClient(int id) {
        String sql = "DELETE FROM client WHERE id = ?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, id);
            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return num;
    }

    public int addClient(Client client) {
        String sql = "INSERT INTO client (id, name, gender, height, weight, dob, disease) VALUES (?,?,?,?,?,?,?)";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, client.getId());
            ps.setObject(2, client.getName());
            ps.setObject(3, client.getGender());
            ps.setObject(4, client.getHeight());
            ps.setObject(5, client.getWeight());
            ps.setObject(6, client.getDob());
            ps.setObject(7, client.getDisease());
            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return num;
    }

    public int updateClient(Client client) {
        String sql = "UPDATE client SET id=?, name=?, gender=?, height=?, weight=?, dob=?, disease=? WHERE id=?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, client.getId());
            ps.setObject(2, client.getName());
            ps.setObject(3, client.getGender());
            ps.setObject(4, client.getHeight());
            ps.setObject(5, client.getWeight());
            ps.setObject(6, client.getDob());
            ps.setObject(7, client.getDisease());
            ps.setObject(8, client.getId());
            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }
        return num;
    }
}
