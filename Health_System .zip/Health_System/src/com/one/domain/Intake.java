package com.one.domain;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Intake objects
 * Date             : 29/03/2024
 */

public class Intake {
    private Integer id;
    private int clientId;
    private String name;
    private String protein;
    private int pWeight;
    private String vegetable;
    private int vWeight;
    private String stableFood;
    private int sWeight;
    private String  fat;
    private int fWeight;
    private String meal;
    private String date;
    private int calories;

    public Intake(Integer id, int clientId, String protein, int pWeight, String vegetable, int vWeight, String stableFood, int sWeight, String fat, int fWeight, String meal, String date) {
        this.id = id;
        this.clientId = clientId;
        this.protein = protein;
        this.pWeight = pWeight;
        this.vegetable = vegetable;
        this.vWeight = vWeight;
        this.stableFood = stableFood;
        this.sWeight = sWeight;
        this.fat = fat;
        this.fWeight = fWeight;
        this.meal = meal;
        this.date = date;
    }

    public Intake(Integer id, String name, String protein, int pWeight, String vegetable, int vWeight, String stableFood, int sWeight, String fat, int fWeight, String meal, String date) {
        this.id = id;
        this.name = name;
        this.protein = protein;
        this.pWeight = pWeight;
        this.vegetable = vegetable;
        this.vWeight = vWeight;
        this.stableFood = stableFood;
        this.sWeight = sWeight;
        this.fat = fat;
        this.fWeight = fWeight;
        this.meal = meal;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProtein() {
        return protein;
    }

    public void setProtein(String protein) {
        this.protein = protein;
    }

    public int getPWeight() {
        return pWeight;
    }

    public void setPWeight(int pWeight) {
        this.pWeight = pWeight;
    }

    public String getVegetable() {
        return vegetable;
    }

    public void setVegetable(String vegetable) {
        this.vegetable = vegetable;
    }

    public int getVWeight() {
        return vWeight;
    }

    public void setVWeight(int vWeight) {
        this.vWeight = vWeight;
    }

    public String getStableFood() {
        return stableFood;
    }

    public void setStableFood(String stableFood) {
        this.stableFood = stableFood;
    }

    public int getSWeight() {
        return sWeight;
    }

    public void setSWeight(int sWeight) {
        this.sWeight = sWeight;
    }

    public String getFat() {
        return fat;
    }

    public void setFat(String fat) {
        this.fat = fat;
    }

    public int getFWeight() {
        return fWeight;
    }

    public void setFWeight(int fWeight) {
        this.fWeight = fWeight;
    }

    public String getMeal() {
        return meal;
    }

    public void setMeal(String meal) {
        this.meal = meal;
    }

    public String  getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories() {
        double calculatedCalories = 0;

        // Calculate calories based on protein
        switch (protein) {
            case "livestock meat":
                calculatedCalories += 2.75 * pWeight;
                break;
            case "poultry":
                calculatedCalories += 1.75 * pWeight;
                break;
            case "fish, shrimp .ect":
                calculatedCalories += 1.15 * pWeight;
                break;
            case "egg":
                calculatedCalories += 1.50 * pWeight;
                break;
            // Add more cases for other protein types if needed
        }

        // Calculate calories based on vegetable
        switch (vegetable) {
            case "root":
                calculatedCalories += 0.6 * vWeight;
                break;
            case "leafy":
            case "cabbage":
                calculatedCalories += 0.25 * vWeight;
                break;
            case "tomato":
                calculatedCalories += 0.2 * vWeight;
                break;
            case "beans":
                calculatedCalories += 1.35 * vWeight;
                break;
            // Add more cases for other vegetable types if needed
        }

        // Calculate calories based on stable food
        switch (stableFood) {
            case "maize":
                calculatedCalories += 0.9 * sWeight;
                break;
            case "rice":
                calculatedCalories += 1.3 * sWeight;
                break;
            case "wheat":
                calculatedCalories += 1.8 * sWeight;
                break;
            case "bread":
                calculatedCalories += 2.3 * sWeight;
                break;
            case "potato":
                calculatedCalories += 0.8 * sWeight;
                break;
            // Add more cases for other stable food types if needed
        }

        // Calculate calories based on fat
        switch (fat) {
            case "animal fat":
                calculatedCalories += 8 * fWeight;
                break;
            case "vegetable oil":
            case "nuts oil":
                calculatedCalories += 9 * fWeight;
                break;
            case "fish oil":
                calculatedCalories += 9.5 * fWeight;
                break;
            // Add more cases for other fat types if needed
        }

        // Set the calculated calories to the class property
        this.calories = (int) calculatedCalories;
    }
}
