package com.one.domain;

import com.one.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DiseaseDAO {
    public static List<Disease> getDisease() {
        String sql = "SELECT disease.id, disease.clientid, client.name, client.gender, client.height, client.weight, client.dob, disease.type, disease.startdate, disease.enddate \n" +
                    "FROM disease \n" +
                    "INNER JOIN client \n" +
                    "ON client.id = disease.clientid";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Disease> list = new ArrayList<>();
        try{
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Integer id = rs.getInt("id");
                String name = rs.getString("name");
                String gender = rs.getString("gender");
                String height = rs.getString("height");
                String weight = rs.getString("weight");
                String dob = rs.getString("dob");
                String diseaseType = rs.getString("type");
                String startDate = rs.getString("startdate");
                String endDate = rs.getString("enddate");
                Disease disease = new Disease(id, name, gender, height, weight, dob, diseaseType, startDate, endDate);
                list.add(disease);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public int addDisease(Disease disease) {
        String sql = "INSERT INTO disease (id, clientid, type, startdate, enddate) VALUES(?, ?, ?, ?, ?)";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, disease.getId());
            ps.setObject(2, disease.getClientId());
            ps.setObject(3, disease.getDisease());
            ps.setObject(4, disease.getStart());
            ps.setObject(5, disease.getEnd());

            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return num;
    }

    public List<Disease> getDiseaseBy(int diseaseId) {
        String sql = "SELECT * FROM disease WHERE id = ? ";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Disease> list = new ArrayList<Disease>();
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, diseaseId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int clientId = rs.getInt("clientid");
                String type = rs.getString("type");
                String start = rs.getString("startdate");
                String end = rs.getString("enddate");
                Disease disease = new Disease(id, clientId, type, start, end);
                list.add(disease);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public int updateDisease(Disease disease) {
        String sql = "UPDATE disease SET id = ?, clientid = ?, type = ?, startdate = ?, enddate = ? WHERE id=?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, disease.getId());
            ps.setObject(2, disease.getClientId());
            ps.setObject(3, disease.getDisease());
            ps.setObject(4, disease.getStart());
            ps.setObject(5, disease.getEnd());
            ps.setObject(6, disease.getId());
            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }
        return num;
    }

    public int delDisease(int id) {
        String sql = "DELETE FROM disease WHERE id = ?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, id);
            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return num;
    }

    public List<Calories> getDiseaseBy(String sportTypes) {
        String sql = "SELECT calories.id, calories.clientid, client.name, client.gender, calories.sporttype, calories.sporttime, calories.walksteps, calories.date " +
                "FROM calories \n" +
                "INNER JOIN client \n" +
                "ON client.id = calories.clientid " +
                "WHERE sporttype = ? ";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Calories> list = new ArrayList<Calories>();
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, sportTypes);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String gender = rs.getString("gender");
                String sportType = rs.getString("sporttype");
                int sportTime = rs.getInt("sporttime");
                int walkSteps = rs.getInt("walksteps");
                String date = rs.getString("date");
                Calories calories = new Calories(id, gender, name, sportType, sportTime, walkSteps, date);
                list.add(calories);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }
}
