package com.one.domain;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Calories Objects
 * Date             : 16/04/2024
 */

public class Calories {
    private Integer id;
    private int clientId;
    private String sportType;
    private int sportTime;
    private int walkSteps;
    private String date;
    private String clientName;
    private String clientGender;
    private int calories;

    public Calories() {

    }

    public Calories(Integer id, int clientId, String sportType, int sportTime, int walkSteps, String date) {
        this.id = id;
        this.clientId = clientId;
        this.sportType = sportType;
        this.sportTime = sportTime;
        this.walkSteps = walkSteps;
        this.date = date;
    }

    public Calories(Integer id, String clientName, String clientGender, String sportType, int sportTime, int walkSteps, String date) {
        this.id = id;
        this.clientName = clientName;
        this.clientGender = clientGender;
        this.sportType = sportType;
        this.sportTime = sportTime;
        this.walkSteps = walkSteps;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getSportType() {
        return sportType;
    }

    public void setSportType(String sportType) {
        this.sportType = sportType;
    }

    public int getSportTime() {
        return sportTime;
    }

    public void setSportTime(int sportTime) {
        this.sportTime = sportTime;
    }

    public int getWalkSteps() {
        return walkSteps;
    }

    public void setWalkSteps(int walkSteps) {
        this.walkSteps = walkSteps;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientGender() {
        return clientGender;
    }

    public void setClientGender(String clientGender) {
        this.clientGender = clientGender;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories() {
        double calculatedCalories = 0;

        switch (sportType) {
            case "ride bike":
                calculatedCalories += 5 * sportTime;
                break;
            case "swim":
            case "soccer":
                calculatedCalories += 8.5 * sportTime;
                break;
            case "baseball":
                calculatedCalories += 8 * sportTime;
            case "basketball":
                calculatedCalories += 7 * sportTime;
                break;
            case "badminton":
                calculatedCalories += 5.5 * sportTime;
                break;
            case "hike":
                calculatedCalories += 9 * sportTime;
            // Add more cases for other protein types if needed
        }

        calculatedCalories += walkSteps * 0.2;

        this.calories = (int) calculatedCalories;
    }
}
