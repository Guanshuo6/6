package com.one.domain;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : Manage intake info as require
 * Date             : 11/04/2024
 */

import com.one.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class IntakeDAO {
    public List<Intake> getIntake() {
        String sql = "SELECT intake.id, intake.clientid, client.name, intake.protein, intake.proweight, intake.vegetable, intake.vegweight, intake.stablefood, intake.staweight, intake.fat, intake.fatweight, intake.meal, intake.date\n" +
                        "FROM intake \n" +
                        "INNER JOIN client \n" +
                        "ON client.id = intake.clientid";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Intake> list = new ArrayList<Intake>();
        try {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String protein = rs.getString("protein");
                int pWeight = rs.getInt("proweight");
                String vegetable = rs.getString("vegetable");
                int vWeight = rs.getInt("vegweight");
                String stableFood = rs.getString("stablefood");
                int sWeight = rs.getInt("staweight");
                String fat = rs.getString("fat");
                int fWeight = rs.getInt("fatweight");
                String date = rs.getString("date");
                String meal = rs.getString("meal");
                Intake intake = new Intake(id, name, protein, pWeight, vegetable, vWeight, stableFood, sWeight, fat, fWeight, meal, date);
                list.add(intake);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public List<Intake> getIntakeBy(int intakeId) {
        String sql = "SELECT * FROM intake WHERE id = ? ";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Intake> list = new ArrayList<Intake>();
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, intakeId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int clientId = rs.getInt("clientid");
                String protein = rs.getString("protein");
                int pWeight = rs.getInt("proweight");
                String vegetable = rs.getString("vegetable");
                int vWeight = rs.getInt("vegweight");
                String stableFood = rs.getString("stablefood");
                int sWeight = rs.getInt("staweight");
                String fat = rs.getString("fat");
                int fWeight = rs.getInt("fatweight");
                String date = rs.getString("date");
                String meal = rs.getString("meal");
                Intake intake = new Intake(id, clientId, protein, pWeight, vegetable, vWeight, stableFood, sWeight, fat, fWeight, meal, date);
                list.add(intake);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public List<Intake> getIntakeBy(String intakeMeal) {
        String sql = "SELECT intake.id, intake.clientid, client.name, intake.protein, intake.proweight, intake.vegetable, intake.vegweight, intake.stablefood, intake.staweight, intake.fat, intake.fatweight, intake.meal, intake.date " +
                    "FROM intake \n" +
                    "INNER JOIN client \n" +
                    "ON client.id = intake.clientid " +
                    "WHERE meal = ? ";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Intake> list = new ArrayList<Intake>();
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, intakeMeal);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String protein = rs.getString("protein");
                int pWeight = rs.getInt("proweight");
                String vegetable = rs.getString("vegetable");
                int vWeight = rs.getInt("vegweight");
                String stableFood = rs.getString("stablefood");
                int sWeight = rs.getInt("staweight");
                String fat = rs.getString("fat");
                int fWeight = rs.getInt("fatweight");
                String date = rs.getString("date");
                String meal = rs.getString("meal");
                Intake intake = new Intake(id, name, protein, pWeight, vegetable, vWeight, stableFood, sWeight, fat, fWeight, meal, date);
                list.add(intake);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public int delIntake(int id) {
        String sql = "DELETE FROM intake WHERE id = ?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, id);
            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return num;
    }

    public int addIntake(Intake intake) {
        String sql = "INSERT INTO intake (id, clientid, protein, proweight, vegetable, vegweight, stablefood, staweight, fat, fatweight, meal, date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, intake.getId());
            ps.setObject(2, intake.getClientId());
            ps.setObject(3, intake.getProtein());
            ps.setObject(4, intake.getPWeight());
            ps.setObject(5, intake.getVegetable());
            ps.setObject(6, intake.getVWeight());
            ps.setObject(7, intake.getStableFood());
            ps.setObject(8, intake.getSWeight());
            ps.setObject(9, intake.getFat());
            ps.setObject(10, intake.getFWeight());
            ps.setObject(11, intake.getMeal());
            ps.setObject(12, intake.getDate());

            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return num;
    }

    public int updateIntake(Intake intake) {
        String sql = "UPDATE intake SET id = ?, clientid = ?, protein = ?, proweight = ?, vegetable = ?, vegweight = ?, stablefood = ?, staweight = ?, fat = ?, fatweight = ?, meal = ?, date = ? WHERE id=?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, intake.getId());
            ps.setObject(2, intake.getClientId());
            ps.setObject(3, intake.getProtein());
            ps.setObject(4, intake.getPWeight());
            ps.setObject(5, intake.getVegetable());
            ps.setObject(6, intake.getVWeight());
            ps.setObject(7, intake.getStableFood());
            ps.setObject(8, intake.getSWeight());
            ps.setObject(9, intake.getFat());
            ps.setObject(10, intake.getFWeight());
            ps.setObject(11, intake.getMeal());
            ps.setObject(12, intake.getDate());
            ps.setObject(13, intake.getId());
            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }
        return num;
    }
}
