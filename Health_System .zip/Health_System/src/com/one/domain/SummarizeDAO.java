package com.one.domain;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : This is summarize
 * Date             : 23/04/2024
 */

import com.one.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class SummarizeDAO {
    public int[] getIntakeClient(String table) {
        // System.out.println("table name: " + table);
        int[] counts = new int[12];
        String sql = "SELECT\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/01/2024%') AS count_01,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/02/2024%') AS count_02,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/03/2024%') AS count_03,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/04/2024%') AS count_04,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/05/2024%') AS count_05,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/06/2024%') AS count_06,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/07/2024%') AS count_07,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/08/2024%') AS count_08,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/09/2024%') AS count_09,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/10/2024%') AS count_10,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/11/2024%') AS count_11,\n" +
                "    (SELECT COUNT(*) FROM " + table + " WHERE date LIKE '%/12/2024%') AS count_12";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                for (int i = 0; i < 12; i++) {
                    counts[i] = rs.getInt("count_" + String.format("%02d", i + 1));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }
        return counts;
    }
}
