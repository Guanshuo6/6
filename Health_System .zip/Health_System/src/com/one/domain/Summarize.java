package com.one.domain;

/*
 * Student Name 01  : Zihan Wang
 * Student ID   01  : C00280203
 * Student Name 02  : Guanshuo Feng
 * Student ID   02  : C00278723
 * Purpose          : This is summarize
 * Date             : 23/04/2024
 */

public class Summarize {
    private int count_01;
    private int count_02;
    private int count_03;
    private int count_04;
    private int count_05;
    private int count_06;
    private int count_07;
    private int count_08;
    private int count_09;
    private int count_10;
    private int count_11;
    private int count_12;

    public Summarize(int count_01, int count_02, int count_03, int count_04, int count_05, int count_06, int count_07, int count_08, int count_09, int count_10, int count_11, int count_12) {
        this.count_01 = count_01;
        this.count_02 = count_02;
        this.count_03 = count_03;
        this.count_04 = count_04;
        this.count_05 = count_05;
        this.count_06 = count_06;
        this.count_07 = count_07;
        this.count_08 = count_08;
        this.count_09 = count_09;
        this.count_10 = count_10;
        this.count_11 = count_11;
        this.count_12 = count_12;
    }

    public int getCount_01() {
        return count_01;
    }

    public void setCount_01(int count_01) {
        this.count_01 = count_01;
    }

    public int getCount_02() {
        return count_02;
    }

    public void setCount_02(int count_02) {
        this.count_02 = count_02;
    }

    public int getCount_03() {
        return count_03;
    }

    public void setCount_03(int count_03) {
        this.count_03 = count_03;
    }

    public int getCount_04() {
        return count_04;
    }

    public void setCount_04(int count_04) {
        this.count_04 = count_04;
    }

    public int getCount_05() {
        return count_05;
    }

    public void setCount_05(int count_05) {
        this.count_05 = count_05;
    }

    public int getCount_06() {
        return count_06;
    }

    public void setCount_06(int count_06) {
        this.count_06 = count_06;
    }

    public int getCount_07() {
        return count_07;
    }

    public void setCount_07(int count_07) {
        this.count_07 = count_07;
    }

    public int getCount_08() {
        return count_08;
    }

    public void setCount_08(int count_08) {
        this.count_08 = count_08;
    }

    public int getCount_09() {
        return count_09;
    }

    public void setCount_09(int count_09) {
        this.count_09 = count_09;
    }

    public int getCount_10() {
        return count_10;
    }

    public void setCount_10(int count_10) {
        this.count_10 = count_10;
    }

    public int getCount_11() {
        return count_11;
    }

    public void setCount_11(int count_11) {
        this.count_11 = count_11;
    }

    public int getCount_12() {
        return count_12;
    }

    public void setCount_12(int count_12) {
        this.count_12 = count_12;
    }
}
