package com.one.domain;

import com.one.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CaloriesDAO {
    public List<Calories> getCalories() {
        String sql = "SELECT calories.id, client.name, client.gender, calories.clientid, calories.sporttype, calories.sporttime, calories.walksteps, calories.date\n" +
                "FROM calories \n" +
                "INNER JOIN client \n" +
                "ON client.id = calories.clientid";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Calories> list = new ArrayList<>();
        try{
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String gender = rs.getString("gender");
                String sportType = rs.getString("sporttype");
                int sportTime = rs.getInt("sporttime");
                int walkSteps = rs.getInt("walksteps");
                String date = rs.getString("date");
                Calories calories = new Calories(id, name, gender, sportType, sportTime, walkSteps, date);
                list.add(calories);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public int addCalories(Calories calories) {
        String sql = "INSERT INTO calories (id, clientid, sporttype, sporttime, walksteps, date) VALUES(?, ?, ?, ?, ?, ?)";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, calories.getId());
            ps.setObject(2, calories.getClientId());
            ps.setObject(3, calories.getSportType());
            ps.setObject(4, calories.getSportTime());
            ps.setObject(5, calories.getWalkSteps());
            ps.setObject(6, calories.getDate());

            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return num;
    }

    public List<Calories> getCaloriesBy(int caloriesId) {
        String sql = "SELECT * FROM calories WHERE id = ? ";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Calories> list = new ArrayList<Calories>();
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, caloriesId);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int clientId = rs.getInt("clientid");
                String sportType = rs.getString("sporttype");
                int sportTime = rs.getInt("sporttime");
                int walkSteps = rs.getInt("walksteps");
                String date = rs.getString("date");
                Calories calories = new Calories(id, clientId, sportType, sportTime, walkSteps, date);
                list.add(calories);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }

    public int updateCalories(Calories calories) {
        String sql = "UPDATE calories SET id = ?, clientid = ?, sporttype = ?, sporttime = ?, walksteps = ?, date = ? WHERE id=?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, calories.getId());
            ps.setObject(2, calories.getClientId());
            ps.setObject(3, calories.getSportType());
            ps.setObject(4, calories.getSportTime());
            ps.setObject(5, calories.getWalkSteps());
            ps.setObject(6, calories.getDate());
            ps.setObject(7, calories.getId());
            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }
        return num;
    }

    public int delCalories(int id) {
        String sql = "DELETE FROM calories WHERE id = ?";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int num = 0;
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, id);
            num = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return num;
    }

    public List<Calories> getCaloriesBy(String sportTypes) {
        String sql = "SELECT calories.id, calories.clientid, client.name, client.gender, calories.sporttype, calories.sporttime, calories.walksteps, calories.date " +
                "FROM calories \n" +
                "INNER JOIN client \n" +
                "ON client.id = calories.clientid " +
                "WHERE sporttype = ? ";
        Connection connection = DBUtil.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Calories> list = new ArrayList<Calories>();
        try {
            ps = connection.prepareStatement(sql);
            ps.setObject(1, sportTypes);
            rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String gender = rs.getString("gender");
                String sportType = rs.getString("sporttype");
                int sportTime = rs.getInt("sporttime");
                int walkSteps = rs.getInt("walksteps");
                String date = rs.getString("date");
                Calories calories = new Calories(id, gender, name, sportType, sportTime, walkSteps, date);
                list.add(calories);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtil.close(connection, ps, rs);
        }

        return list;
    }
}
