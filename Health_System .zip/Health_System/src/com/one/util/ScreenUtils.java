package com.one.util;

import java.awt.*;

public class ScreenUtils {


    /*
        Get width of screen
     */
    public static int getScreenWidth(){
        return Toolkit.getDefaultToolkit().getScreenSize().width;
    }

    /*
        Get height of screen
     */

    public static int getScreenHeight(){
        return Toolkit.getDefaultToolkit().getScreenSize().height;
    }
}
